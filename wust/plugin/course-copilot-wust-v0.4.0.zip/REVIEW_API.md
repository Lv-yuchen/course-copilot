# 武科大评价网站接口预留

配置一个 HTTPS 接口地址，例如 https://你的域名/api/reviews，不包含查询参数、凭据或锚点。插件首次保存时请求该域名权限，尚未配置时不发起评价请求。

## 请求

GET 请求参数：course_name（必填）、course_code（页面有编号时）、teacher（引擎查询确定单个教师时）。不发送学号、登录 Cookie 或课表。credentials=omit，重定向禁止，超时 10 秒。课程名和教师名称属于接口查询数据。

## 响应

返回标准化的原 ReviewSearchResult。空结果：

```json
{"reviews":[],"warnings":[]}
```

reviews 内每个元素遵守原项目 packages/core/src/types/course.ts 中 CourseReview；分组与归属由评价服务处理。当前适配器校验 courseName、normalizedName、reviewCount，provider 自动设置为 wust-reviews。正式接入网站前还需增加完整响应 schema 校验。

必要领域字段还包括 gradedSampleCount（有效百分制成绩样本数，没有时为 0）。可选字段包括 courseCode、teacher、normalizedTeacher、teacherNames、gradeFriendliness、workloadFriendliness、attendanceFriendliness、overallScore、meanGrade、courseReviewCount 等。四项友好度为 0–10，平均成绩为 0–100；缺失数据省略，不能用 0 伪造未知值。

原引擎实际按 aspects 中的证据计算推荐；仅提供四个友好度数值不能替代评价证据。aspects 结构见 packages/core/src/aspects/types.ts 中 AspectAnalysis / AspectScore，包括维度分数、证据评论数、提及数和命中词等。可同时返回 courseLevel、teachingClassLevel、courseSupplementary、reviewExcerpts 等原 ReviewSearchResult 字段。教师聚合和课程聚合的归属必须符合原接口语义，不能把其他老师的评价标成当前教学班评价。

本版预留的是标准化评价接口，不是 Excel 原表的直接上传接口。后续处理腾讯评价表时，需要确定字段映射和从原始评价生成上述证据的步骤，再完成网站适配。
