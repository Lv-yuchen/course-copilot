# Course Copilot 武科大版 v0.3.0

主插件侧栏整合版。沿用原版侧栏样式、四项偏好、推荐卡片及原推荐引擎，接入已在 Edge 实测成功的武科大课程读取模块。

## 使用

在 Edge 扩展管理页加载 course-copilot-wust-v0.3.0 文件夹。先停用独立识别测试插件，以免同时运行两套查询流程。刷新已登录的武科大选课入口，点击本插件工具栏图标打开侧栏。

点击“过滤并加载可选课程信息”：先选择所有课程、清空搜索条件，勾选三个过滤项并查询；等待刷新后读一页、保存一页，最后汇总。侧栏展示全部 14 列课程信息。取消、失败、历史结果均标注状态，支持 JSON 导出。课程数据按浏览器标签页 ID 存储，关闭再打开侧栏可继续查看；关闭原标签页后新标签页不会自动使用旧页面数据。

评价网站尚未配置时显示“尚未接入评价数据”，不请求武大评价网站、不产生虚构分数。四项偏好及原评分引擎均保留。未来网站接口见 REVIEW_API.md；配置接口时仅请求该 HTTPS 域名的访问权限。

## 工程和验证

- 可维护源目录：apps/wust-extension。
- 构建：node scripts/build-wust-extension.mjs，不需要额外 npm 包。
- 测试：node --test apps/wust-reader/reader.test.cjs apps/wust-extension/integration.test.mjs。
- wust-reader.js 来自独立识别模块 v0.2.2，构建时同步。
- vendor/engine.mjs 来自用户提供的已构建 v1.0.0 service-worker，截取完整引擎和策略至 row-to-course 边界，并导出已有函数。评分、匹配、权重与置信度算法内容未修改。包中保留原 provider 定义供原算法引用，但运行入口注入 WustReviewProvider，不构造或调用原武大 provider。
- vendor/presentation.mjs 复用原侧栏的卡片与偏好函数，移除原页面启动逻辑。
- 原 TypeScript 工程和独立插件保留。当前这条构建路线复用用户提供的编译产物；如需修改算法，应回到原 TypeScript 包构建，不能直接维护 vendor 算法副本。

课程识别 v0.2.2 已由用户在实际 Edge 页面验证两页共 20 个教学班，完整且无警告。此主侧栏整合版已进行代码测试，尚未在实际 Edge 安装后验证全部消息、展示与生命周期。未来评价接口尚无实际网站可测。
