export function validateEndpoint(value) {
  const url=new URL(value);
  if(url.protocol!=='https:'||url.username||url.password||url.search||url.hash)throw new Error('评价接口须为 HTTPS 地址，不包含账号、密码、查询参数或锚点。');
  if(url.hostname==='whucourses.cn'||url.hostname==='bkjx.wust.edu.cn')throw new Error('请使用独立的武科大评价网站接口。');
  return url;
}
export class WustReviewProvider {
  id='wust-reviews';label='武科大课程评价';
  constructor(endpoint){this.endpoint=validateEndpoint(endpoint);this.homepage=this.endpoint.origin;}
  async isAvailable(){return true;}
  async searchCourse(query){
    const url=new URL(this.endpoint);
    url.searchParams.set('course_name',query.courseName);
    if(query.courseCode)url.searchParams.set('course_code',query.courseCode);
    if(query.teacher)url.searchParams.set('teacher',query.teacher);
    const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),10000);
    const abort=()=>controller.abort();query.signal?.addEventListener('abort',abort,{once:true});
    try{
      if(query.signal?.aborted)controller.abort();
      const response=await fetch(url,{method:'GET',credentials:'omit',redirect:'error',signal:controller.signal,headers:{accept:'application/json'}});
      if(!response.ok)throw new Error(`评价接口返回 HTTP ${response.status}`);
      const value=await response.json();
      if(!value||!Array.isArray(value.reviews))throw new Error('评价接口必须返回包含 reviews 数组的 JSON。');
      for(const row of value.reviews){if(typeof row.courseName!=='string'||!row.courseName.trim()||typeof row.normalizedName!=='string'||!Number.isInteger(row.reviewCount)||row.reviewCount<0)throw new Error('评价记录缺少课程名、标准化名称或有效评价数量。');}
      return {...value,provider:this.id,fromCache:false,warnings:Array.isArray(value.warnings)?value.warnings:[],reviews:value.reviews.map(r=>({...r,provider:this.id}))};
    }finally{clearTimeout(timer);query.signal?.removeEventListener('abort',abort);}
  }
}
