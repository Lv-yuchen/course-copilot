/* Reusable DOM adapter; no review requests, enrollment, or personal timetable reads. */
(function (root) {
  'use strict';
  const HOST = 'bkjx.wust.edu.cn';
  const PATH = '/jsxsd/xsxk/xsxk_index';
  const LABELS = ['课程编号','课程名','课程学分','合班名称','分组名','上课老师','上课时间','上课地点','上课校区','限选人数','剩余容量','时间冲突','通选课类别','操作'];
  const KEYS = ['courseCode','courseName','credits','className','groupName','teacher','schedule','location','campus','capacity','remainingSeats','conflict','category','operation'];
  const clean = value => String(value ?? '').replace(/\u00a0/g, ' ').trim();
  const number = value => /^\d+(?:\.\d+)?$/.test(clean(value)) ? Number(clean(value)) : undefined;
  function cellText(cell) {
    const walk = node => node.nodeType === 3 ? node.textContent : node.nodeName === 'BR' ? '\n' : Array.from(node.childNodes || []).map(walk).join('');
    return clean(walk(cell)).split('\n').map(clean).filter(Boolean).join('\n');
  }
  function supported(url) {
    try { const u = new URL(url); return u.protocol === 'https:' && u.hostname === HOST && u.pathname === PATH; } catch { return false; }
  }
  function parseCells(headers, values, sectionId) {
    const fields = {};
    for (let i = 0; i < headers.length; i++) fields[clean(headers[i])] = clean(values[i]);
    if (!fields['课程编号'] || !fields['课程名']) return null;
    const course = { source: 'wust', fields, sectionId: sectionId || undefined };
    LABELS.forEach((label, i) => { course[KEYS[i]] = fields[label] ?? ''; });
    course.credits = number(fields['课程学分']);
    course.capacity = number(fields['限选人数']);
    course.remainingSeats = number(fields['剩余容量']);
    course.availability = course.remainingSeats === undefined ? 'unknown' : course.remainingSeats > 0 ? 'available' : 'full';
    course.selectable = course.availability === 'available' && !course.conflict && course.operation.includes('选课') && !/不可|不能|已选|退选/.test(course.operation);
    return course;
  }
  function identity(course) {
    return course.sectionId || JSON.stringify([course.courseCode,course.className,course.groupName,course.teacher,course.schedule,course.location,course.campus]);
  }
  function pagination(text) {
    const m = clean(text).match(/当前显示\s*(\d+)\s*到\s*(\d+)\s*条[，,]\s*共\s*(\d+)\s*条记录/)
      || clean(text).match(/显示\s*(\d+)\s*至\s*(\d+)\s*共\s*(\d+)\s*项/);
    return m ? { start: Number(m[1]), end: Number(m[2]), total: Number(m[3]) } : null;
  }
  function create(topDocument, pageUrl) {
    let running = false;
    let cancelled = false;
    let lastResult = null;
    let diagnostics = [];
    function frameDocument() {
      if (!supported(pageUrl)) throw new Error('当前网址不是支持的武科大选课入口。');
      let d;
      try { d = topDocument.querySelector('#mainFrame')?.contentDocument; } catch { /* report inaccessible frame */ }
      if (!d) throw new Error('课程区域尚未加载，或无法访问 mainFrame。');
      const table = d.querySelector('#dataView');
      if (!table) throw new Error('未检测到公选课课程表，请打开“公选课选课”。');
      const headers = Array.from(table.querySelectorAll('thead th')).map(e => clean(e.textContent));
      if (!LABELS.every(label => headers.includes(label))) throw new Error('课程表字段发生变化，已停止读取。');
      return d;
    }
    function snapshot() {
      const d = frameDocument();
      const table = d.querySelector('#dataView');
      const headers = Array.from(table.querySelectorAll('thead th')).map(e => clean(e.textContent));
      const courses = [];
      const warnings = [];
      for (const row of table.querySelectorAll('tbody tr')) {
        const cells = Array.from(row.cells);
        if (cells.length === 1 && cells[0].classList.contains('dataTables_empty')) continue;
        if (cells.length !== headers.length) { warnings.push('遇到列数不匹配的课程行，未读取该行。'); continue; }
        const operationCell = cells[headers.indexOf('操作')];
        const href = operationCell?.querySelector('a')?.getAttribute('href') || '';
        const section = href.match(/^javascript:xsxkFun\('([^']+)'/);
        const course = parseCells(headers, cells.map(cellText), section?.[1]);
        if (course) courses.push(course); else warnings.push('遇到缺少课程编号或课程名的行。');
      }
      const category = d.querySelector('#szjylb');
      const next = d.querySelector('#dataView_next');
      return { supported: true, headers, courses, warnings,
        category: category?.selectedOptions[0]?.textContent || '',
        categories: Array.from(category?.options || []).filter(o => o.value !== '').map(o => ({ value:o.value,label:clean(o.textContent) })),
        pagination: pagination(d.querySelector('#dataView_info')?.textContent),
        hasNext: Boolean(next && !next.classList.contains('paginate_button_disabled')),
        filters: { full:d.querySelector('#sfym')?.checked, conflict:d.querySelector('#sfct')?.checked, restricted:d.querySelector('#sfxx')?.checked }
      };
    }
    function signature(s) { return JSON.stringify([s.pagination, s.courses.map(c => [identity(c), c.remainingSeats])]); }
    function checkAbort() { if (cancelled) throw new Error('读取已取消，已读取的课程已保留。'); }
    async function waitAfter(action, before, query = false) {
      const d = frameDocument();
      const target = d.querySelector('#dataView');
      let mutated = false;
      const Observer = topDocument.defaultView.MutationObserver;
      const observer = new Observer(() => { mutated = true; });
      observer.observe(target, { childList:true,subtree:true,characterData:true });
      let stable = ''; let since = 0;
      const deadline = Date.now() + 30000;
      try {
        action(d);
        while (Date.now() < deadline) {
          checkAbort();
          await new Promise(resolve => setTimeout(resolve, 150));
          // Re-resolve the frame: a query may replace the entire document or table.
          let live;
          try { live = frameDocument(); } catch (error) {
            if (/尚未加载|未检测到公选课课程表/.test(error.message)) { stable=''; continue; }
            throw error;
          }
          const replaced = live !== d || live.querySelector('#dataView') !== target;
          const processing = live.querySelector('#dataView_processing');
          const processingStyle = processing ? live.defaultView.getComputedStyle(processing) : null;
          const busy = Boolean(processing && !processing.hidden && processingStyle.display !== 'none'
            && processingStyle.visibility !== 'hidden' && processingStyle.visibility !== 'collapse');
          const filterReady = ['#sfym','#sfct','#sfxx'].every(id=>live.querySelector(id)?.checked === true);
          const diagnostic = {stage:query?'query':'pagination',mutated,replaced,busy,filterReady,
            processingDisplay:processingStyle?.display,processingVisibility:processingStyle?.visibility,
            paginationText:clean(live.querySelector('#dataView_info')?.textContent)};
          if (JSON.stringify(diagnostics.at(-1)) !== JSON.stringify(diagnostic)) diagnostics.push(diagnostic);
          if (diagnostics.length>40) diagnostics.shift();
          if (busy || !filterReady || (query && !mutated && !replaced)) { stable=''; continue; }
          const current = snapshot();
          const sig = signature(current);
          if (current.pagination && (query ? mutated || replaced : sig !== before)) {
            if (stable !== sig) { stable = sig; since = Date.now(); }
            if (Date.now() - since >= 450) return current;
          } else { stable = ''; }
        }
        throw new Error('课程查询或翻页未在 30 秒内确认完成，已停止。请导出 JSON，其中包含等待诊断信息。');
      } finally { observer.disconnect(); }
    }
    function clickQuery(d) {
      const button = d.querySelector('input[type="button"][value="查询"][onclick="queryKxkcList()"]');
      if (!button) throw new Error('未找到经过核实的课程查询按钮。');
      button.click();
    }
    function setCheck(d, id, value) {
      const control = d.querySelector(id);
      if (!control || control.type !== 'checkbox') throw new Error('未找到课程筛选控件：' + id);
      if (control.checked !== value) control.click();
    }
    async function collect(options = {}) {
      if (running) throw new Error('已有读取任务正在运行。');
      running = true; cancelled = false; diagnostics=[];
      const courses = new Map(); const warnings = [];
      let pagesRead = 0; let categoriesRead = 0;
      const publish = extra => options.onProgress?.({pagesRead,categoriesRead,courseCount:courses.size,...extra});
      try {
        const d = frameDocument();
        const select = d.querySelector('#szjylb');
        const availableCategories = Array.from(select?.options || []).filter(o=>o.value!=='').map(o=>({value:o.value,label:clean(o.textContent)}));
        // The verified '所有课程' option includes all categories; avoid ten duplicate searches.
        const categories = options.perCategory && availableCategories.length ? availableCategories : [{value:'',label:'所有课程'}];
        for (const category of categories) {
          checkAbort(); publish({phase:'query',category:category.label});
          const before = null;
          let current = await waitAfter(d => {
            const select = d.querySelector('#szjylb');
            if (!select) throw new Error('未找到课程类别下拉框。');
            select.value = category.value;
            select.dispatchEvent(new d.defaultView.Event('change', {bubbles:true}));
            // All-category scan must not inherit text/time restrictions from a previous manual search.
            for (const id of ['#kch','#kcmc','#fzmc','#hbmc','#skls','#skxq','#skjc']) {
              const control = d.querySelector(id);
              if (!control) throw new Error('未找到课程筛选字段：' + id);
              control.value = '';
            }
            setCheck(d,'#sfym',true); setCheck(d,'#sfct',true); setCheck(d,'#sfxx',true);
            clickQuery(d);
          }, before, true);
          const seen = new Set();
          for (let page = 0; page < 200; page++) {
            checkAbort();
            const sig = signature(current);
            if (seen.has(sig)) throw new Error('检测到重复分页，已停止读取。');
            seen.add(sig); pagesRead++;
            warnings.push(...current.warnings);
            if (current.warnings.length) throw new Error('课程行结构异常，汇总尚未完成。');
            for (const course of current.courses) if (course.selectable) courses.set(identity(course),course);
            const pageResult = {status:'reading',courses:[...courses.values()],warnings:[...new Set(warnings)],pagesRead,categoriesRead,
              category:category.label,pagination:current.pagination,pageCourses:current.courses,readAt:new Date().toISOString()};
            // Persist BEFORE attempting the next page. A storage failure must stop, not silently lose a checkpoint.
            if (options.onPage) await options.onPage(pageResult);
            lastResult = pageResult;
            publish({phase:'reading',category:category.label,pagination:current.pagination});
            if (!current.hasNext) {
              if (!current.pagination || current.pagination.end < current.pagination.total) throw new Error('课程分页不完整，未找到下一页。');
              break;
            }
            if (page === 199) throw new Error('超过单类别 200 页上限，已停止读取。');
            const expectedTotal = current.pagination?.total;
            current = await waitAfter(d => {
              const next = d.querySelector('#dataView_next');
              if (!next || next.classList.contains('paginate_button_disabled')) throw new Error('下一页状态变化，已停止。');
              next.click();
            },sig);
            if (current.pagination?.total !== expectedTotal) throw new Error('选课期间课程总数发生变化，分页结果可能有遗漏，请重新读取。');
          }
          categoriesRead++;
        }
        lastResult = {status:'complete',courses:[...courses.values()],warnings:[...new Set(warnings)],pagesRead,categoriesRead,diagnostics,readAt:new Date().toISOString()};
      } catch (error) {
        lastResult = {status:cancelled?'cancelled':'failed',courses:[...courses.values()],warnings:[...new Set(warnings)],error:error.message,pagesRead,categoriesRead,diagnostics,readAt:new Date().toISOString()};
      } finally { running = false; }
      publish({phase:lastResult.status});
      return lastResult;
    }
    return { snapshot,collect,cancel:()=>{cancelled=true;},get running(){return running;},get result(){return lastResult;} };
  }
  const api = {supported,parseCells,identity,pagination,create,LABELS,KEYS};
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.WustCourseReader = api;
})(typeof globalThis === 'undefined' ? this : globalThis);
