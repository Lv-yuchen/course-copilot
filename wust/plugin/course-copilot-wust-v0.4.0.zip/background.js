import {LocalWustReviewProvider} from './local-reviews.js';
import {recommendExtensionCourses,normalizeCourseName,normalizeTeacherName} from './vendor/engine.mjs';
import {WustReviewProvider,validateEndpoint} from './reviews.js';
chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:true}).catch(()=>{});
const validTab=id=>Number.isInteger(id)&&id>=0;
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(message.type==='WUST_PROGRESS'&&sender.tab){
    chrome.runtime.sendMessage({type:'WUST_PANEL_PROGRESS',tabId:sender.tab.id,progress:message.progress}).catch(()=>{});return;
  }
  if(sender.tab)return;
  if(['WUST_STATUS','WUST_START','WUST_CANCEL'].includes(message.type)){
    if(!validTab(message.tabId)){reply({ok:false,error:'当前标签页无效。'});return;}
    chrome.tabs.sendMessage(message.tabId,message).then(reply).catch(e=>reply({ok:false,error:'无法连接选课页面，请确认网址并刷新页面。'+e.message}));return true;
  }
  if(message.type==='WUST_RECOMMEND'){
    (async()=>{
      if(!validTab(message.tabId))throw new Error('标签页无效。');
      const saved=await chrome.storage.local.get([`wust.courses.${message.tabId}`,'wust.reviewEndpoint','wust.localReviews']);
      const snapshot=saved[`wust.courses.${message.tabId}`];const endpoint=saved['wust.reviewEndpoint'];
      const local=saved['wust.localReviews'];
      if(!local?.rows?.length&&!endpoint){reply({ok:true,configured:false});return;}
      if(snapshot?.status!=='complete')throw new Error('请先完整读取当前标签页的课程。');
      let provider;
      if(local?.rows?.length)provider=new LocalWustReviewProvider(local);
      else {const url=validateEndpoint(endpoint);
      if(!await chrome.permissions.contains({origins:[`${url.origin}/*`]}))throw new Error('尚未授予该评价网站访问权限。');
      provider=new WustReviewProvider(endpoint);}
      const courses=snapshot.courses.map(row=>({...row,normalizedName:normalizeCourseName(row.courseName),normalizedTeacher:normalizeTeacherName(row.teacher||''),sourceCourseId:row.sectionId}));
      const result=await recommendExtensionCourses({courses,provider,options:{preferences:message.preferences},coverage:{coursesDiscovered:new Set(courses.map(c=>c.courseCode)).size,sectionsDiscovered:courses.length,sectionsHydrated:courses.length,exhausted:true}});
      reply({ok:true,configured:true,result});
    })().catch(e=>reply({ok:false,error:e.message}));return true;
  }
});
