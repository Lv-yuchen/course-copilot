(() => {
  const reader = WustCourseReader.create(document,location.href);
  let activeTabId=null;
  const key=id=>`wust.courses.${id}`;
  const persist=result=>chrome.storage.local.set({[key(activeTabId)]:{...result,pageUrl:location.href,sourceTabId:activeTabId}});
  chrome.runtime.onMessage.addListener((message,sender,reply)=>{
    if(sender.id!==chrome.runtime.id)return;
    if(message.type==='WUST_STATUS'){reply({supported:WustCourseReader.supported(location.href),running:reader.running});return;}
    if(message.type==='WUST_CANCEL'){reader.cancel();reply({ok:true});return;}
    if(message.type!=='WUST_START')return;
    if(!Number.isInteger(message.tabId)||reader.running){reply({ok:false,error:'已有读取任务或标签页无效。'});return;}
    activeTabId=message.tabId;
    (async()=>{
      const result=await reader.collect({onPage:async page=>{await persist(page);},onProgress:progress=>{
        chrome.runtime.sendMessage({type:'WUST_PROGRESS',progress}).catch(()=>{});
      }});
      await persist(result);
      reply({ok:true,result:{...result,pageUrl:location.href,sourceTabId:activeTabId}});
    })().catch(error=>reply({ok:false,error:error.message}));
    return true;
  });
})();
