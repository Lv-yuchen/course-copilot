import {renderCourseCards,preferencePayloadOf,preferencePercentagesOf,preferenceProblemOf} from '../vendor/presentation.mjs';
import {validateEndpoint} from '../reviews.js';
const $=id=>document.getElementById(id);
const element=(tag,text)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;return e;};
const key=id=>`wust.courses.${id}`;
let tabId=null,viewTabId=null,snapshot=null,busy=false,remoteRunning=false,recommendationGeneration=0;
const panel= document.querySelector('main');
const storageSection=element('section');storageSection.className='panel-autoload';
const historical=element('button','查看上次保存');const download=element('button','导出课程 JSON');download.disabled=true;
storageSection.append(historical,download);$('full-preparation').append(storageSection);
const listSection=element('section');listSection.className='panel-cards';listSection.append(element('h2','可选课程完整信息'));const list=element('div');listSection.append(list);panel.insertBefore(listSection,$('recommendation')||document.querySelector('.panel-facts'));
const endpointSection=element('details');const endpointSummary=element('summary','评价来源设置');const endpointInput=element('input');endpointInput.type='url';endpointInput.placeholder='https://你的评价网站/api/reviews';endpointInput.style.width='100%';const endpointSave=element('button','保存接口地址');const endpointStatus=element('p');
endpointSection.append(endpointSummary,element('p','网站尚未搭建时可以留空。接入后沿用原推荐算法。'),endpointInput,endpointSave,endpointStatus);panel.insertBefore(endpointSection,listSection);
const css=element('link');css.rel='stylesheet';css.href='wust.css';document.head.append(css);
const show=(id,text)=>{const e=$(id);if(e){e.textContent=text;e.hidden=false;if(id.startsWith('recommendation-'))$('recommendation').hidden=false;}};
function weights(){return Object.fromEntries(['gradeFriendliness','workloadFriendliness','attendanceFriendliness','overallScore'].map(k=>[k,Number($('preference-'+k).value)]));}
function updateWeights(){const values=weights();const percentages=preferencePercentagesOf(values);Object.keys(values).forEach((k,i)=>{$('preference-value-'+k).textContent=values[k]+'/10';$('preference-percent-'+k).textContent=percentages[i]+'%';});}
function cardsRoot(){return {recommended:$('card-list-recommended'),rated:$('card-list-rated'),insufficient:$('card-list-insufficient'),sections:{recommended:$('cards-recommended'),rated:$('cards-rated'),insufficient:$('cards-insufficient')},disclaimer:$('grade-disclaimer'),disclosure:{toggle:$('rated-toggle'),panel:$('rated-cards'),count:$('rated-count')}};}
function clearRecommendation(){recommendationGeneration++;renderCourseCards(cardsRoot(),null);}
function renderSnapshot(value,historicalView=false){
  snapshot=value;download.disabled=!value;list.replaceChildren();if(!value)return;
  show('panel-count',`已保存教学班：${value.courses.length}`);
  const time=new Date(value.readAt).toLocaleString('zh-CN');
  list.append(element('p',`${historicalView?'历史结果，余量可能已变化。':'读取结果。'} 保存时间：${time}；${value.status==='complete'?'完整列表':'部分列表，尚未完成'}。`));
  for(const c of value.courses){const article=element('article');article.className='course-card';article.append(element('h3',c.courseName));const dl=element('dl');dl.className='wust-fields';for(const label of WustCourseReader.LABELS)dl.append(element('dt',label),element('dd',c.fields[label]||(label==='时间冲突'?'页面未标注冲突':'暂无数据')));article.append(dl);list.append(article);}
}
async function activeTab(){return (await chrome.tabs.query({active:true,currentWindow:true}))[0]?.id??null;}
async function refresh(){if(busy)return;const id=await activeTab();viewTabId=id;if(id!==tabId){tabId=id;snapshot=null;renderSnapshot(null);clearRecommendation();}
  const answer=await chrome.runtime.sendMessage({type:'WUST_STATUS',tabId});remoteRunning=answer.running===true;show('page-status',answer.supported?'已识别武汉科技大学选课页面':'请打开武科大公选课选课页面，或刷新页面。');$('full-preparation-start').disabled=!answer.supported||remoteRunning;$('full-preparation-cancel').hidden=!remoteRunning;historical.disabled=remoteRunning;}
async function recommend(){const generation=++recommendationGeneration;const requestedTab=tabId;const problem=preferenceProblemOf(weights());if(problem){show('recommendation-message',problem.code==='all_zero'?'至少有一项重要程度需要大于 0。':'偏好值必须是 0 到 10 的整数。');return;}
  if(snapshot?.status!=='complete'){show('recommendation-message','先完整读取当前页面课程，再生成推荐。');return;}
  show('recommendation-message','正在检查评价来源…');
  try{const answer=await chrome.runtime.sendMessage({type:'WUST_RECOMMEND',tabId:requestedTab,preferences:preferencePayloadOf(weights())});if(generation!==recommendationGeneration||requestedTab!==await activeTab())return;
    if(!answer.ok)throw new Error(answer.error);
    if(!answer.configured){renderCourseCards(cardsRoot(),null);show('recommendation-message','尚未接入武科大评价数据。课程读取已完成；接入评价网站后，可按当前偏好生成推荐。');return;}
    renderCourseCards(cardsRoot(),answer.result);show('recommendation-message',`推荐 ${answer.result.recommendations.length} 个教学班；评价证据不足 ${answer.result.insufficientData.length} 个。`);
  }catch(e){show('recommendation-message',e.message);}
}
$('full-preparation-start').onclick=async()=>{
  if(busy)return;tabId=await activeTab();const requestedTab=tabId;busy=true;clearRecommendation();renderSnapshot(null);$('full-preparation-start').disabled=true;$('full-preparation-cancel').hidden=false;historical.disabled=true;show('full-preparation-message','正在勾选三个过滤项并查询，尚未读取课程。');
  try{const answer=await chrome.runtime.sendMessage({type:'WUST_START',tabId:requestedTab});if(!answer.ok)throw new Error(answer.error);if(requestedTab!==await activeTab()){show('full-preparation-message','原标签页读取结果已保存，请切回该选课页面查看。');return;}renderSnapshot(answer.result);show('full-preparation-message',answer.result.status==='complete'?`读取完成：${answer.result.pagesRead} 页、${answer.result.courses.length} 个教学班。`:answer.result.error);if(answer.result.status==='complete')await recommend();}catch(e){show('full-preparation-message',e.message);}finally{busy=false;historical.disabled=false;$('full-preparation-start').disabled=false;$('full-preparation-cancel').hidden=true;await refresh();}
};
$('full-preparation-cancel').onclick=()=>chrome.runtime.sendMessage({type:'WUST_CANCEL',tabId});
chrome.runtime.onMessage.addListener(message=>{if(message.type==='WUST_PANEL_PROGRESS'&&message.tabId===viewTabId&&(busy||remoteRunning)){const p=message.progress;show('full-preparation-message',p.phase==='query'?'正在过滤和查询，等待列表刷新…':`已读取并保存 ${p.pagesRead} 页，汇总 ${p.courseCount} 个教学班。`);}});
chrome.storage.onChanged.addListener((changes,area)=>{if(area!=='local')return;const next=changes[key(viewTabId)]?.newValue;if(next&&(busy||remoteRunning)){renderSnapshot(next);if(next.status!=='reading'&&!busy){remoteRunning=false;refresh().catch(()=>{});show('full-preparation-message',next.status==='complete'?'课程读取完成。':next.error||'读取中断。');}}});
historical.onclick=async()=>{await refresh();const saved=await chrome.storage.local.get(key(tabId));clearRecommendation();renderSnapshot(saved[key(tabId)],true);if(!snapshot)show('full-preparation-message','当前标签页尚无保存数据。');};
download.onclick=()=>{if(!snapshot)return;const url=URL.createObjectURL(new Blob([JSON.stringify(snapshot,null,2)],{type:'application/json'}));const a=element('a');a.href=url;a.download='wust-courses.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
endpointSave.onclick=async()=>{try{const text=endpointInput.value.trim();if(text){const url=validateEndpoint(text);if(!await chrome.permissions.request({origins:[`${url.origin}/*`]}))throw new Error('未授予该评价网站访问权限。');}await chrome.storage.local.set({'wust.reviewEndpoint':text});clearRecommendation();endpointStatus.textContent=text?'接口已保存。':'评价接口已清空。';}catch(e){endpointStatus.textContent=e.message;}};
for(const k of Object.keys(weights()))$('preference-'+k).oninput=updateWeights;
for(const button of document.querySelectorAll('button')){if(button.textContent.trim()==='更新推荐')button.onclick=recommend;if(button.textContent.trim()==='恢复默认')button.onclick=()=>{Object.entries({gradeFriendliness:10,workloadFriendliness:6,attendanceFriendliness:3,overallScore:1}).forEach(([k,v])=>$('preference-'+k).value=v);updateWeights();};}
$('rated-toggle').onclick=()=>{const target=$('rated-cards');target.hidden=!target.hidden;$('rated-toggle').setAttribute('aria-expanded',String(!target.hidden));};
chrome.tabs.onActivated.addListener(info=>{viewTabId=info.tabId;if(busy){renderSnapshot(null);clearRecommendation();show('page-status','已切换标签页，原选课页面仍在读取和保存。');return;}refresh().catch(()=>{});});chrome.tabs.onUpdated.addListener((id,change)=>{if(id===tabId&&change.status==='complete')refresh().catch(()=>{});});
$('fact-version').textContent=chrome.runtime.getManifest().version;updateWeights();refresh().catch(e=>show('page-status',e.message));chrome.storage.local.get('wust.reviewEndpoint').then(v=>endpointInput.value=v['wust.reviewEndpoint']||'');show('recommendation-message','尚未接入评价数据，先读取可选课程。');
