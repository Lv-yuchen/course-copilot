import {classifyDelivery,groupByDelivery,DELIVERY_MODES,DELIVERY_LABELS} from '../delivery-mode.js';
import {validateLocalReviews} from '../local-reviews.js';
import {recommendationResultView,renderCourseCards,preferencePayloadOf,preferencePercentagesOf,preferenceProblemOf} from '../vendor/presentation.mjs';
import {validateEndpoint} from '../reviews.js';
const $=id=>document.getElementById(id);
const element=(tag,text)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;return e;};
const key=id=>`wust.courses.${id}`;
let tabId=null,viewTabId=null,snapshot=null,busy=false,remoteRunning=false,recommendationGeneration=0,refreshGeneration=0;
const panel= document.querySelector('main');
const deliveryStatus=element('p');deliveryStatus.className='wust-delivery-status';deliveryStatus.hidden=true;$('full-preparation').append(deliveryStatus);
const storageSection=element('details');storageSection.className='wust-secondary';storageSection.append(element('summary','历史数据与导出'));
const historical=element('button','查看上次保存');const download=element('button','导出课程 JSON');download.disabled=true;
storageSection.append(historical,download);panel.insertBefore(storageSection,document.querySelector('.panel-facts'));
const listSection=element('details');listSection.className='wust-secondary';const listSummary=element('summary','读取详情');listSection.append(listSummary);const list=element('div');listSection.append(list);panel.insertBefore(listSection,document.querySelector('.panel-facts'));
const endpointSection=element('details');const endpointSummary=element('summary','评价来源设置');const endpointInput=element('input');endpointInput.type='url';endpointInput.placeholder='https://你的评价网站/api/reviews';endpointInput.style.width='100%';const endpointSave=element('button','保存接口地址');const endpointStatus=element('p');
endpointSection.append(endpointSummary,element('p','网站尚未搭建时可以留空。接入后沿用原推荐算法。'),endpointInput,endpointSave,endpointStatus);endpointSection.className='wust-secondary';panel.insertBefore(endpointSection,storageSection);
const css=element('link');css.rel='stylesheet';css.href='wust.css';document.head.append(css);
const show=(id,text)=>{const e=$(id);if(e){e.textContent=text;e.hidden=false;if(id.startsWith('recommendation-'))$('recommendation').hidden=false;}};
function weights(){return Object.fromEntries(['gradeFriendliness','workloadFriendliness','attendanceFriendliness','overallScore'].map(k=>[k,Number($('preference-'+k).value)]));}
function updateWeights(){const values=weights();const percentages=preferencePercentagesOf(values);Object.keys(values).forEach((k,i)=>{$('preference-value-'+k).textContent=values[k]+'/10';$('preference-percent-'+k).textContent=percentages[i]+'%';});const problem=preferenceProblemOf(values);$('preferences-apply').disabled=!!problem;$('preferences-problem').hidden=!problem;$('preferences-problem').textContent=problem?(problem.code==='all_zero'?'至少有一项重要程度需要大于 0。':'偏好值必须是 0 到 10 的整数。'):'';}
function cardsRoot(){return {recommended:$('card-list-recommended'),rated:$('card-list-rated'),insufficient:$('card-list-insufficient'),sections:{recommended:$('cards-recommended'),rated:$('cards-rated'),insufficient:$('cards-insufficient')},disclaimer:$('grade-disclaimer'),disclosure:{toggle:$('rated-toggle'),panel:$('rated-cards'),count:$('rated-count')}};}
function clearRecommendation(){recommendationGeneration++;renderCourseCards(cardsRoot(),null);for(const id of ['recommendation-counts','recommendation-empty','recommendation-review-notice','recommendation-teacher-notice','recommendation-message']){$(id).hidden=true;}for(const kind of ['recommended','rated','insufficient'])$('recommendation-count-'+kind).textContent='0';}
function renderResult(result){
  const view=recommendationResultView({status:'success',result,page:{read:'ok',supported:true,rowCount:snapshot.courses.length,courseCount:new Set(snapshot.courses.map(c=>c.courseName)).size}},null);
  const unavailable=result.reviewSource?.status==='unavailable';
  renderCourseCards(cardsRoot(),unavailable||!view.counts?null:result);$('cards-insufficient').open=false;
  if(!unavailable&&view.counts)renderDeliveryCards(result);
  $('recommendation-counts').hidden=unavailable||!view.counts;
  if(view.counts)for(const kind of ['recommended','rated','insufficient'])$('recommendation-count-'+kind).textContent=String(view.counts[kind]);
  if(view.reviewNotice)show('recommendation-review-notice',view.reviewNotice);
  const empty=unavailable?null:view.emptyNotice;$('recommendation-empty').hidden=!empty;if(empty)$('recommendation-empty').textContent=empty;
  const counts=view.counts;
  show('recommendation-message',view.pageNotice||(unavailable?'评价来源暂时不可用，请稍后重试；本次未生成推荐。':counts?.recommended?`已生成 ${counts.recommended} 个教学班推荐。`:counts?.rated?'已有课程评价，但没有教学班进入推荐。':`已读取 ${snapshot.courses.length} 个教学班，当前评价证据不足。`));
  $('insufficient-summary').textContent=`评价证据不足（${counts?.insufficient||0} 个教学班）`;
}
function renderDeliveryCards(result){
  const root=$('card-list-recommended');const nodes=Array.from(root.children);root.replaceChildren();
  const groups=groupByDelivery(snapshot.courses);
  for(const mode of DELIVERY_MODES){
    if((mode==='mixed'||mode==='unknown')&&!groups[mode].length)continue;
    const section=element('li');section.className='wust-delivery-group';section.append(element('h4',DELIVERY_LABELS[mode]));const cards=element('ol');cards.className='course-card-list';let count=0;
    result.recommendations.forEach((entry,i)=>{if(classifyDelivery(entry.course).mode===mode){const facts=classifyDelivery(entry.course);nodes[i].append(element('p',`授课方式：${facts.label}；地点：${facts.location||'未提供'}`));cards.append(nodes[i]);count++;}});
    if(count)section.append(cards);else{const state=result.deliveryGroups?.[mode]?.result.reviewSource?.status;section.append(element('p',!groups[mode].length?'当前没有此类可选课程。':state==='unavailable'?'此类课程评价来源暂时不可用。':'此类课程暂无推荐，可在下方查看评价证据不足或未进入推荐的课程。'));}
    root.append(section);
  }
  $('cards-recommended').hidden=false;
  result.ratedButNotRecommended.forEach((entry,i)=>{const c=classifyDelivery(entry.course);$('card-list-rated').children[i]?.append(element('p',`授课方式：${c.label}；地点：${c.location||'未提供'}`));});
  const insufficientRoot=$('card-list-insufficient');const insufficientNodes=Array.from(insufficientRoot.children);insufficientRoot.replaceChildren();
  for(const mode of DELIVERY_MODES){
    const entries=result.insufficientData.map((entry,index)=>({entry,index})).filter(({entry})=>classifyDelivery(entry.course).mode===mode);
    if((mode==='mixed'||mode==='unknown')&&!entries.length)continue;
    const section=element('li');section.className='wust-delivery-group';section.append(element('h4',`${DELIVERY_LABELS[mode]}（${entries.length} 个教学班）`));
    if(entries.length){const cards=element('ol');cards.className='course-card-list';for(const {entry,index} of entries){const c=classifyDelivery(entry.course);insufficientNodes[index].append(element('p',`授课方式：${c.label}；地点：${c.location||'未提供'}`));cards.append(insufficientNodes[index]);}section.append(cards);}else section.append(element('p','没有此类评价证据不足的课程。'));
    insufficientRoot.append(section);
  }
}
function renderSnapshot(value,historicalView=false){
  snapshot=value;download.disabled=!value;deliveryStatus.hidden=!value;if(value){const groups=groupByDelivery(value.courses);deliveryStatus.textContent=DELIVERY_MODES.map(mode=>`${DELIVERY_LABELS[mode]} ${groups[mode].length}`).join(' · ');}list.replaceChildren();if(!value){$('panel-count').hidden=true;listSummary.textContent='读取详情';return;}
  show('panel-count',`已读取 ${value.pagesRead||0} 页，共 ${value.courses.length} 个教学班${value.status==='complete'?'':'（尚未完成）'}`);
  const time=new Date(value.readAt).toLocaleString('zh-CN');
  list.append(element('p',`${historicalView?'历史结果，余量可能已变化。':'读取结果。'} 保存时间：${time}；${value.status==='complete'?'完整列表':'部分列表，尚未完成'}。`));
  listSummary.textContent=`读取详情（${value.courses.length} 个教学班）`;
  if(listSection.open)renderDetails();
}
function renderDetails(){
  if(!snapshot)return;
  while(list.children.length>1)list.lastChild.remove();
  for(const c of snapshot.courses){const article=element('article');article.className='course-card';article.append(element('h3',c.courseName));const classification=classifyDelivery(c);article.append(element('p',`${classification.label}：${classification.reason}`));const dl=element('dl');dl.className='wust-fields';for(const label of WustCourseReader.LABELS)dl.append(element('dt',label),element('dd',c.fields[label]||(label==='时间冲突'?'页面未标注冲突':'暂无数据')));article.append(dl);list.append(article);}
}
listSection.ontoggle=()=>{if(listSection.open)renderDetails();};

async function activeTab(){return (await chrome.tabs.query({active:true,currentWindow:true}))[0]?.id??null;}
async function refresh(restore=false){
  if(busy)return;const generation=++refreshGeneration;const id=await activeTab();if(generation!==refreshGeneration)return;
  viewTabId=id;const changed=id!==tabId;if(changed){tabId=id;renderSnapshot(null);clearRecommendation();}
  const answer=await chrome.runtime.sendMessage({type:'WUST_STATUS',tabId:id});if(id!==await activeTab()||generation!==refreshGeneration)return;
  remoteRunning=answer.running===true;show('page-status',answer.supported?'已识别武汉科技大学选课页面':'请打开武科大公选课选课页面，或刷新页面。');$('full-preparation-start').disabled=!answer.supported||remoteRunning;$('full-preparation-cancel').hidden=!remoteRunning;historical.disabled=remoteRunning;
  if(!answer.supported)return;
  if(changed||restore){const saved=await chrome.storage.local.get(key(id));if(id!==await activeTab()||generation!==refreshGeneration)return;const value=saved[key(id)];if(value?.sourceTabId===id){renderSnapshot(value,!remoteRunning);show('full-preparation-message',remoteRunning?'已恢复读取任务，继续等待课程保存。':value.status==='complete'?'已恢复上次保存的完整课程，余量请以学校页面为准。':value.error||'上次读取未完成，请重新读取。');if(value.status==='complete'&&!remoteRunning)await recommend();}else if(remoteRunning)show('full-preparation-message','正在读取课程，等待第一页保存。');}
}
async function recommend(){clearRecommendation();const generation=recommendationGeneration;const requestedTab=tabId;const problem=preferenceProblemOf(weights());if(problem){show('recommendation-message',problem.code==='all_zero'?'至少有一项重要程度需要大于 0。':'偏好值必须是 0 到 10 的整数。');return;}
  if(snapshot?.status!=='complete'){show('recommendation-message','先完整读取当前页面课程，再生成推荐。');return;}
  show('recommendation-message','正在检查评价来源…');
  try{const answer=await chrome.runtime.sendMessage({type:'WUST_RECOMMEND',tabId:requestedTab,preferences:preferencePayloadOf(weights())});const currentTab=await activeTab();if(generation!==recommendationGeneration||requestedTab!==currentTab)return;
    if(!answer.ok)throw new Error(answer.error);
    if(!answer.configured){renderCourseCards(cardsRoot(),null);show('recommendation-message','尚未接入武科大评价数据。课程读取已完成；导入本地评价或接入评价网站后，可按当前偏好生成推荐。');return;}
    renderResult(answer.result);
  }catch(e){const currentTab=await activeTab();if(generation!==recommendationGeneration||requestedTab!==currentTab)return;show('recommendation-message','生成推荐失败：'+e.message);}
}
$('full-preparation-start').onclick=async()=>{
  if(busy||remoteRunning)return;refreshGeneration++;tabId=await activeTab();viewTabId=tabId;const requestedTab=tabId;busy=true;clearRecommendation();renderSnapshot(null);$('full-preparation-start').disabled=true;$('full-preparation-cancel').hidden=false;historical.disabled=true;show('full-preparation-message','正在勾选三个过滤项并查询，尚未读取课程。');
  try{const answer=await chrome.runtime.sendMessage({type:'WUST_START',tabId:requestedTab});if(!answer.ok)throw new Error(answer.error);if(requestedTab!==await activeTab()){show('full-preparation-message','原标签页读取结果已保存，请切回该选课页面查看。');return;}renderSnapshot(answer.result);show('full-preparation-message',answer.result.status==='complete'?`读取完成：${answer.result.pagesRead} 页、${answer.result.courses.length} 个教学班。`:answer.result.error);if(answer.result.status==='complete')await recommend();}catch(e){show('full-preparation-message',e.message);}finally{busy=false;historical.disabled=false;$('full-preparation-start').disabled=false;$('full-preparation-cancel').hidden=true;await refresh();}
};
$('full-preparation-cancel').onclick=()=>chrome.runtime.sendMessage({type:'WUST_CANCEL',tabId});
chrome.runtime.onMessage.addListener(message=>{if(message.type==='WUST_PANEL_PROGRESS'&&message.tabId===viewTabId&&(busy||remoteRunning)){const p=message.progress;show('full-preparation-message',p.phase==='query'?'正在过滤和查询，等待列表刷新…':`已读取并保存 ${p.pagesRead} 页，汇总 ${p.courseCount} 个教学班。`);}});
chrome.storage.onChanged.addListener((changes,area)=>{if(area!=='local')return;const next=changes[key(viewTabId)]?.newValue;if(next&&(busy||remoteRunning)){renderSnapshot(next);if(next.status!=='reading'&&!busy){remoteRunning=false;refresh().catch(()=>{});show('full-preparation-message',next.status==='complete'?'课程读取完成。':next.error||'读取中断。');if(next.status==='complete')recommend().catch(()=>{});}}});
historical.onclick=async()=>{await refresh();const saved=await chrome.storage.local.get(key(tabId));clearRecommendation();renderSnapshot(saved[key(tabId)],true);if(!snapshot)show('full-preparation-message','当前标签页尚无保存数据。');};
download.onclick=()=>{if(!snapshot)return;const url=URL.createObjectURL(new Blob([JSON.stringify(snapshot,null,2)],{type:'application/json'}));const a=element('a');a.href=url;a.download='wust-courses.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
endpointSave.onclick=async()=>{try{const text=endpointInput.value.trim();if(text){const url=validateEndpoint(text);if(!await chrome.permissions.request({origins:[`${url.origin}/*`]}))throw new Error('未授予该评价网站访问权限。');}await chrome.storage.local.set({'wust.reviewEndpoint':text});clearRecommendation();endpointStatus.textContent=text?'接口已保存。':'评价接口已清空。';}catch(e){endpointStatus.textContent=e.message;}};
for(const k of Object.keys(weights()))$('preference-'+k).oninput=updateWeights;
for(const button of document.querySelectorAll('button')){if(button.textContent.trim()==='更新推荐')button.onclick=recommend;if(button.textContent.trim()==='恢复默认')button.onclick=()=>{Object.entries({gradeFriendliness:10,workloadFriendliness:6,attendanceFriendliness:3,overallScore:1}).forEach(([k,v])=>$('preference-'+k).value=v);updateWeights();};}
$('rated-toggle').onclick=()=>{const target=$('rated-cards');target.hidden=!target.hidden;$('rated-toggle').setAttribute('aria-expanded',String(!target.hidden));};
chrome.tabs.onActivated.addListener(info=>{viewTabId=info.tabId;if(busy){renderSnapshot(null);clearRecommendation();show('page-status','已切换标签页，原选课页面仍在读取和保存。');return;}refresh().catch(()=>{});});chrome.tabs.onUpdated.addListener((id,change)=>{if(id===tabId&&change.status==='complete')refresh(true).catch(()=>{});});
$('fact-version').textContent=chrome.runtime.getManifest().version;updateWeights();refresh(true).catch(e=>show('page-status',e.message));chrome.storage.local.get('wust.reviewEndpoint').then(v=>endpointInput.value=v['wust.reviewEndpoint']||'');show('recommendation-message','尚未接入评价数据，先读取可选课程。');

const reviewFile=element('input');reviewFile.type='file';reviewFile.accept='.json,application/json';
const reviewStatus=element('p');const reviewClear=element('button','清除本地评价');
endpointSection.append(element('p','导入转换后的本地评价 JSON。已有本地评价时优先使用本地数据，无需配置网站。'),reviewFile,reviewStatus,reviewClear);
function localStatus(data){reviewStatus.textContent=data?.rows?.length?`已导入 ${data.rows.length} 条评价，${new Set(data.rows.map(r=>r.courseName)).size} 门课程。来源：${data.sourceFile||'本地文件'}。`:'尚未导入本地评价。';}
reviewFile.onchange=async()=>{try{const file=reviewFile.files?.[0];if(!file)return;if(file.size>8*1024*1024)throw new Error('评价文件不能超过 8 MB。');const data=validateLocalReviews(JSON.parse(await file.text()));if(!data.rows.length)throw new Error('评价文件没有有效记录。');await chrome.storage.local.set({'wust.localReviews':data});localStatus(data);clearRecommendation();if(snapshot?.status==='complete')await recommend();}catch(e){reviewStatus.textContent='导入失败：'+e.message;}finally{reviewFile.value='';}};
reviewClear.onclick=async()=>{await chrome.storage.local.remove('wust.localReviews');localStatus(null);clearRecommendation();if(snapshot?.status==='complete')await recommend();};
chrome.storage.local.get('wust.localReviews').then(v=>localStatus(v['wust.localReviews']));
