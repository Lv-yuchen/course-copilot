import {recommendExtensionCourses,mergeReviewSourceHealth,buildDataCoverage} from './vendor/engine.mjs';
import {DELIVERY_MODES,groupByDelivery} from './delivery-mode.js';
export async function recommendByDelivery({courses,provider,options}){
 const groups=groupByDelivery(courses),deliveryGroups={};let merged;
 for(const mode of DELIVERY_MODES){
  const candidates=groups[mode];if(!candidates.length)continue;
  const result=await recommendExtensionCourses({courses:candidates,provider,options,coverage:{coursesDiscovered:new Set(candidates.map(c=>c.courseCode||c.courseName)).size,sectionsDiscovered:candidates.length,sectionsHydrated:candidates.length,exhausted:true}});
  deliveryGroups[mode]={candidateCount:candidates.length,result};
  if(!merged)merged={...result,recommendations:[],ratedButNotRecommended:[],insufficientData:[],excluded:[],ambiguousCandidates:[],considered:0,reviewSource:result.reviewSource};else merged.reviewSource=mergeReviewSourceHealth(merged.reviewSource,result.reviewSource);
  merged.considered+=result.considered;merged.meta.usedCache ||= result.meta.usedCache;
  for(const key of ['recommendations','ratedButNotRecommended','insufficientData','excluded','ambiguousCandidates'])merged[key].push(...result[key]);
 }
 if(!merged)merged=await recommendExtensionCourses({courses:[],provider,options});
 merged.dataCoverage=buildDataCoverage({coursesDiscovered:new Set(courses.map(c=>c.courseCode||c.courseName)).size,sectionsDiscovered:courses.length,sectionsHydrated:courses.length,exhausted:true});
 return {...merged,deliveryGroups};
}
