(function () {
  'use strict';
  if (!WustCourseReader.supported(location.href) || document.querySelector('#wust-course-reader')) return;
  const reader = WustCourseReader.create(document,location.href);
  const host = document.createElement('div'); host.id='wust-course-reader';
  Object.assign(host.style,{position:'fixed',right:'16px',bottom:'16px',zIndex:'2147483647'});
  const shadow = host.attachShadow({mode:'open'});
  shadow.innerHTML = `<style>
    :host{font:14px/1.6 system-ui;color:#16314b}section{width:440px;max-width:90vw;background:white;border:1px solid #cbd7e5;border-radius:12px;box-shadow:0 8px 36px #10243a33;padding:16px}h2{font-size:17px;margin:0 0 8px}button{cursor:pointer;border:1px solid #bdcce0;border-radius:6px;background:#eff5fd;padding:6px 10px;margin:4px 4px 4px 0}button:disabled{opacity:.5;cursor:default}.list{max-height:48vh;overflow:auto}.course{border-top:1px solid #e0e8f1;padding:12px 0}dl{display:grid;grid-template-columns:88px 1fr;gap:4px;margin:8px 0}dt{color:#687b8e}dd{margin:0;white-space:pre-wrap;overflow-wrap:anywhere}.error{color:#b3261e}small{color:#687b8e}.head{display:flex;justify-content:space-between}.fold{display:none}p{margin:8px 0}
  </style><section><div class="head"><h2>武科大课程识别</h2><button id="fold">收起</button></div><div id="body"><p id="status">已识别武科大选课入口，等待开始。</p><small>先勾选三个过滤项并查询，等网页刷新后再读取。使用“所有课程”，清空课程及时间搜索条件；每页保存后再翻页，结束后停在最后读取的位置。</small><div><button id="all">过滤并读取可选课程</button><button id="cancel" disabled>取消</button><button id="history">查看上次保存</button><button id="export" disabled>导出 JSON</button></div><p id="progress"></p><div class="list" id="list"></div><small>独立识别插件 v0.2.0</small></div></section>`;
  document.documentElement.appendChild(host);
  const $ = id=>shadow.getElementById(id);
  let result = null;
  const STORAGE_KEY='wustCourseReader.latest';
  const persist=async value=>{await chrome.storage.local.set({[STORAGE_KEY]:value});};
  function render(courses) {
    $('list').replaceChildren();
    for (const c of courses) {
      const article=document.createElement('article'); article.className='course';
      const title=document.createElement('strong'); title.textContent=c.courseName;article.append(title);
      const dl=document.createElement('dl');
      for(const label of WustCourseReader.LABELS){const dt=document.createElement('dt');dt.textContent=label;const dd=document.createElement('dd');dd.textContent=c.fields[label] || '暂无数据';dl.append(dt,dd);}
      article.append(dl);$('list').append(article);
    }
  }
  $('fold').onclick=()=>{$('body').classList.toggle('fold');$('fold').textContent=$('body').classList.contains('fold')?'展开':'收起';};
  $('cancel').onclick=()=>reader.cancel();
  $('all').onclick=async()=>{
    $('all').disabled=true;$('history').disabled=true;$('export').disabled=true;$('cancel').disabled=false;$('progress').className='';
    result=null;render([]);$('status').textContent='正在过滤和查询，尚未读取课程。';
    result=await reader.collect({onPage:async page=>{$('status').textContent='正在保存当前页…';await persist(page);result=page;render(page.courses);},onProgress:p=>{if(p.phase==='query'){$('progress').textContent='正在勾选三个过滤项并查询，等待页面刷新…';}else{$('status').textContent='已完成筛选，正在读取并保存课程。';$('progress').textContent=`已读取 ${p.pagesRead} 页，已保存 ${p.courseCount} 门可选教学班`;}}});
    try{await persist(result);}catch(e){result={...result,status:'failed',error:'本地保存失败：'+e.message};}
    render(result.courses);$('progress').className=result.status==='failed'?'error':'';
    $('progress').textContent=result.status==='complete'?`汇总完成：${result.categoriesRead} 类、${result.pagesRead} 页、${result.courses.length} 门可选教学班。`:`${result.error} 已保留 ${result.courses.length} 门；此结果不代表完整列表。`;
    $('status').textContent=result.status==='complete'?'读取与保存完成。':result.status==='cancelled'?'已取消，已保存结果保留。':'读取未完成。';
    $('all').disabled=false;$('history').disabled=false;$('cancel').disabled=true;$('export').disabled=false;
  };
  $('export').onclick=()=>{const url=URL.createObjectURL(new Blob([JSON.stringify(result,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='wust-courses.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
  $('history').onclick=async()=>{try{const saved=await chrome.storage.local.get(STORAGE_KEY);const value=saved[STORAGE_KEY];if(reader.running)return;if(!value){$('progress').textContent='尚无保存数据。';return;}result=value;render(value.courses||[]);$('export').disabled=false;$('status').textContent='正在查看历史保存结果，余量可能已变化。';$('progress').textContent=`上次保存 ${value.courses?.length||0} 门（${value.readAt||'时间未知'}），状态：${value.status}。重新读取可更新余量。`;}catch(e){$('progress').textContent='无法读取本地保存数据：'+e.message;}};
})();
