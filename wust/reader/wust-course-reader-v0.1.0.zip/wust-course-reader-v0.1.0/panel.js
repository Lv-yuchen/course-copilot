(function () {
  'use strict';
  if (!WustCourseReader.supported(location.href) || document.querySelector('#wust-course-reader')) return;
  const reader = WustCourseReader.create(document,location.href);
  const host = document.createElement('div'); host.id='wust-course-reader';
  Object.assign(host.style,{position:'fixed',right:'16px',bottom:'16px',zIndex:'2147483647'});
  const shadow = host.attachShadow({mode:'open'});
  shadow.innerHTML = `<style>
    :host{font:14px/1.6 system-ui;color:#16314b}section{width:440px;max-width:90vw;background:white;border:1px solid #cbd7e5;border-radius:12px;box-shadow:0 8px 36px #10243a33;padding:16px}h2{font-size:17px;margin:0 0 8px}button{cursor:pointer;border:1px solid #bdcce0;border-radius:6px;background:#eff5fd;padding:6px 10px;margin:4px 4px 4px 0}button:disabled{opacity:.5;cursor:default}.list{max-height:48vh;overflow:auto}.course{border-top:1px solid #e0e8f1;padding:12px 0}dl{display:grid;grid-template-columns:88px 1fr;gap:4px;margin:8px 0}dt{color:#687b8e}dd{margin:0;white-space:pre-wrap;overflow-wrap:anywhere}.error{color:#b3261e}small{color:#687b8e}.head{display:flex;justify-content:space-between}.fold{display:none}p{margin:8px 0}
  </style><section><div class="head"><h2>武科大课程识别</h2><button id="fold">收起</button></div><div id="body"><p id="status">正在识别公选课页面…</p><small>读取全部类别并启用已满、冲突、限选过滤；清空课程及时间查询条件。会切换类别和分页，结束后停在最后读取的位置。</small><div><button id="scan">读取当前页</button><button id="all">汇总全部可选课程</button><button id="cancel" disabled>取消</button><button id="export" disabled>导出 JSON</button></div><p id="progress"></p><div class="list" id="list"></div><small>识别模块 v0.1.0 · 评价接口与推荐算法待接入</small></div></section>`;
  document.documentElement.appendChild(host);
  const $ = id=>shadow.getElementById(id);
  let result = null;
  const STORAGE_KEY='wustCourseReader.latest';
  const persist=async value=>{await chrome.storage.local.set({[STORAGE_KEY]:value});};
  function render(courses) {
    $('list').replaceChildren();
    for (const c of courses) {
      const article=document.createElement('article'); article.className='course';
      const title=document.createElement('strong'); title.textContent=c.courseName;article.append(title);
      const dl=document.createElement('dl');
      for(const label of WustCourseReader.LABELS){const dt=document.createElement('dt');dt.textContent=label;const dd=document.createElement('dd');dd.textContent=c.fields[label] || '暂无数据';dl.append(dt,dd);}
      article.append(dl);$('list').append(article);
    }
  }
  function scan() {try{const s=reader.snapshot();$('status').textContent=`已识别武科大公选课页面 · ${s.category}`; result={status:'current_page',...s};render(s.courses);$('progress').textContent=`当前页 ${s.courses.length} 条；网站共 ${s.pagination?.total ?? '未知'} 条。`;$('export').disabled=false;}catch(e){$('status').textContent=e.message;}}
  $('scan').onclick=scan;
  $('fold').onclick=()=>{$('body').classList.toggle('fold');$('fold').textContent=$('body').classList.contains('fold')?'展开':'收起';};
  $('cancel').onclick=()=>reader.cancel();
  $('all').onclick=async()=>{
    $('all').disabled=true;$('scan').disabled=true;$('cancel').disabled=false;$('progress').className='';
    result=await reader.collect({onPage:async page=>{await persist(page);result=page;render(page.courses);},onProgress:p=>{$('progress').textContent=`${p.category || ''} · 已读取 ${p.pagesRead} 页、${p.categoriesRead} 类，汇总 ${p.courseCount} 门可选教学班`;}});
    try{await persist(result);}catch(e){result={...result,status:'failed',error:'本地保存失败：'+e.message};}
    render(result.courses);$('progress').className=result.status==='failed'?'error':'';
    $('progress').textContent=result.status==='complete'?`汇总完成：${result.categoriesRead} 类、${result.pagesRead} 页、${result.courses.length} 门可选教学班。`:`${result.error} 已保留 ${result.courses.length} 门；此结果不代表完整列表。`;
    $('all').disabled=false;$('scan').disabled=false;$('cancel').disabled=true;$('export').disabled=false;
  };
  $('export').onclick=()=>{const url=URL.createObjectURL(new Blob([JSON.stringify(result,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='wust-courses.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
  scan();
  chrome.storage.local.get(STORAGE_KEY).then(saved=>{const value=saved[STORAGE_KEY];if(!value||reader.running)return;result=value;render(value.courses||[]);$('export').disabled=false;$('progress').textContent=`已恢复上次保存的 ${value.courses?.length||0} 门课程（${value.readAt||'时间未知'}），状态：${value.status}。请重新读取以更新余量。`;}).catch(e=>{$('progress').textContent='无法读取本地保存数据：'+e.message;});
})();
