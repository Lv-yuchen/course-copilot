# 武科大独立课程识别插件 v0.2.2

这是独立可加载的识别模块，位于原源码工程的 apps/wust-reader。当前没有接入原侧栏、评价网站或推荐流程；原推荐算法未修改。

在 Edge / Chrome 的扩展管理页加载本目录，刷新已登录的武科大选课入口，页面右下角显示识别面板。初始化只判断网址，不读取课程，也不自动展示历史结果。

点击“过滤并读取可选课程”后，先使用网站“所有课程”选项，勾选过滤已满、冲突、限选三个选项，再点击查询。等查询刷新课程列表之后才读取课程数据，汇总全部类别的筛选结果。有下一页时读一页存一页，没有下一页时直接保存当前完整结果。每页在翻页之前写入 chrome.storage.local；“查看上次保存”可恢复历史数据并导出 JSON。恢复数据不会自动继续翻页，余量仍需重新读取。支持取消。

汇总会清空课程代码、课程名称、分组名称、合班名称、教师、星期、节次搜索条件。扫描结束后页面停在最后读取的类别和分页。网站筛选之外，再检查余量大于 0、无冲突、页面提供选课操作；这些条件不保证提交时仍能选上。

## 已核实页面

- HTTPS 域名 bkjx.wust.edu.cn，路径 /jsxsd/xsxk/xsxk_index；不固定选课轮次参数。
- 公选课列表在 mainFrame 内，课程表 dataView。
- 14 列字段，保留原始文本；课程代码保持字符串，多段时间和地点保留换行。
- 类别控件 szjylb；满课 sfym；冲突 sfct；限选 sfxx。
- 分页 dataView_info、dataView_next，禁用类 paginate_button_disabled。
- 本次真实样本第一页 15 条，总计 222 条；样本用于回归测试，数量随网站改变。

## 接口

经典脚本加载 wust-reader.js 后提供 WustCourseReader。使用 create(document, location.href) 返回 reader。

- snapshot()：当前分类、当前页课程、字段、分页、筛选状态与类别列表。
- collect({onProgress,onPage,perCategory})：异步汇总。onPage 在下一页操作前等待保存回调完成；perCategory=true 时逐类别查询，默认使用“所有课程”查询。返回 status（complete / cancelled / failed）、courses、warnings、error（失败时）、pagesRead、categoriesRead、readAt。
- cancel()：取消读取，保留已经汇总的课程。

每条记录包含 courseCode、courseName、credits、teacher、className、groupName、schedule、location、campus、capacity、remainingSeats、conflict、category、operation、sectionId、availability、selectable，以及所有 14 列的 fields 原文。sectionId 只从课程操作链接中读取教学班标识，不执行链接。与推荐层整合时使用 source=wust，并携带全部教学班标识与扩展字段。

## 验证

运行 node --test apps/wust-reader/reader.test.cjs。测试包括真实课程样本、字段顺序变化、空教师、零与未知余量、冲突、多段时间、不同教学班去重、类别分页遍历与取消。

真实页面已通过内置浏览器读取 DOM。真实筛选查询把 222 条缩小到 28 条；随后点击下一页，网站显示第 16 至 24 条、共 24 条，读取的 9 条均有余量且无冲突。因为实时选课导致总数变化，模块新增总数变化中止保护。类别切换实测过程中工具超时，全部类别仍未跑完。内置浏览器未提供本地扩展加载能力，真实页面操作与解析函数测试不能替代扩展安装后的完整端到端测试。

模块的完整汇总流程在模拟实际 DOM 协议的回归测试中验证。


v0.2.2 修复查询等待：每次轮询重新获取 mainFrame 文档，兼容整个内嵌页面或课程表替换；等待 30 秒，失败 JSON 附带诊断信息。用户截图确认 v0.2.0 在查询等待阶段失败，但尚未确认该用户页面的具体刷新方式。新增两项回归测试，总计 12 项通过。


v0.2.2：用户 JSON 显示列表已变为 22 条、过滤已勾选，但 busy 一直为 true。内置浏览器实测 dataView_processing 的 style 是 visibility: hidden。修正加载判断，同时检查 display 和 visibility，避免把隐藏的加载提示当成加载中。13 项测试通过。
