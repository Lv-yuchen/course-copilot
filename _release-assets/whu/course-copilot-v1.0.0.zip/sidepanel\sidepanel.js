"use strict";
(() => {
  // apps/extension/src/sidepanel/full-preparation.ts
  var PREPARATION_START_MESSAGE = "COURSE_COPILOT_START_FULL_PREPARATION";
  var PREPARATION_CANCEL_MESSAGE = "COURSE_COPILOT_CANCEL_FULL_PREPARATION";
  var PREPARATION_STATUS_MESSAGE = "COURSE_COPILOT_QUERY_FULL_PREPARATION_STATUS";
  var PREPARATION_EVENT_MESSAGE = "COURSE_COPILOT_FULL_PREPARATION_EVENT";
  var PREPARATION_MESSAGES = {
    starting: "\u6B63\u5728\u5F00\u59CB\u2026",
    /*
     * The filtered pool is what the whole run is about, so the wording says 可选课程 rather than 全部课程. The old wording promised the complete WHU catalogue, which
     * this flow deliberately does not assemble: it prepares the courses that currently have places.
     */
    filteringAvailable: "\u6B63\u5728\u7B5B\u9009\u53EF\u9009\u8BFE\u7A0B\u2026",
    loadingCourses: "\u6B63\u5728\u52A0\u8F7D\u53EF\u9009\u8BFE\u7A0B\u2026",
    hydratingTeachers: "\u6B63\u5728\u8865\u5168\u6559\u5E08\u4FE1\u606F\u2026",
    rescanning: "\u6B63\u5728\u91CD\u65B0\u8BFB\u53D6\u8BFE\u7A0B\u4FE1\u606F\u2026",
    completed: "\u53EF\u9009\u8BFE\u7A0B\u4FE1\u606F\u5DF2\u51C6\u5907\u5B8C\u6210",
    teacherPartial: "\u8BFE\u7A0B\u4FE1\u606F\u5DF2\u90E8\u5206\u51C6\u5907\u5B8C\u6210\uFF0C\u90E8\u5206\u6559\u5E08\u4FE1\u606F\u672A\u80FD\u8865\u5168\u3002",
    teacherCap: "\u5DF2\u8FBE\u5230\u6559\u5E08\u4FE1\u606F\u8865\u5168\u4E0A\u9650\uFF0C\u5F53\u524D\u5DF2\u83B7\u53D6\u7684\u6570\u636E\u5DF2\u4FDD\u7559\u3002",
    cancelled: "\u5DF2\u505C\u6B62\u6570\u636E\u51C6\u5907\uFF0C\u5DF2\u7ECF\u52A0\u8F7D\u7684\u4FE1\u606F\u4F1A\u4FDD\u7559\u3002",
    listIncomplete: "\u8BFE\u7A0B\u5217\u8868\u672A\u80FD\u5B8C\u6574\u52A0\u8F7D\uFF0C\u56E0\u6B64\u672A\u7EE7\u7EED\u8865\u5168\u6559\u5E08\u4FE1\u606F\u3002",
    /*
     * The two filter refusals are kept apart because the user's next move differs. `unavailable` means this page exposes no 「有余量」 filter to operate — nothing
     * was clicked — while `failed` means the filter was there and did not take, so the pool would not have been the selectable one and the run stopped rather
     * than prepare something the approval did not cover.
     */
    filterUnavailable: "\u5F53\u524D\u9875\u9762\u65E0\u6CD5\u4F7F\u7528 WHU \u7684\u201C\u6709\u4F59\u91CF\u201D\u7B5B\u9009\uFF0C\u56E0\u6B64\u672A\u5F00\u59CB\u51C6\u5907\u6570\u636E\u3002",
    filterFailed: "\u672A\u80FD\u542F\u7528\u201C\u6709\u4F59\u91CF\u201D\u7B5B\u9009\uFF0C\u56E0\u6B64\u672A\u5F00\u59CB\u51C6\u5907\u6570\u636E\u3002",
    readFailed: "\u8BFE\u7A0B\u4FE1\u606F\u91CD\u65B0\u8BFB\u53D6\u5931\u8D25\u3002",
    /** A refusal or a transport failure: nothing was started, and this is not a preparation outcome. */
    failed: "\u65E0\u6CD5\u5F00\u59CB\u6570\u636E\u51C6\u5907\u3002"
  };
  function preparationProgressText(phase, clicks, hydration) {
    if (phase === "starting") return PREPARATION_MESSAGES.starting;
    if (phase === "filtering_available") return PREPARATION_MESSAGES.filteringAvailable;
    if (phase === "loading_courses") {
      return `${PREPARATION_MESSAGES.loadingCourses} \u5DF2\u5C55\u5F00 ${clicks} \u6279`;
    }
    if (phase === "hydrating_teachers") {
      const parts = [PREPARATION_MESSAGES.hydratingTeachers];
      if (hydration !== null) {
        const queued = hydration.queued;
        const considered = hydration.considered;
        if (typeof considered === "number" && typeof queued === "number") {
          parts.push(`\u5DF2\u5904\u7406 ${considered} / ${queued} \u4E2A\u8BFE\u7A0B\u9762\u677F`);
        }
        const details = [];
        if (typeof hydration.hydrated === "number") details.push(`\u6210\u529F\u8865\u5168 ${hydration.hydrated}`);
        if (typeof hydration.skipped === "number") details.push(`\u65E0\u9700\u8865\u5168 ${hydration.skipped}`);
        if (typeof hydration.failed === "number") details.push(`\u5931\u8D25 ${hydration.failed}`);
        if (details.length > 0) parts.push(details.join(" \xB7 "));
      }
      return parts.join(" ");
    }
    if (phase === "rescanning") return PREPARATION_MESSAGES.rescanning;
    return null;
  }
  function preparationFinishText(stopReason) {
    switch (stopReason) {
      case "completed":
      case "teacher_hydration_completed":
        return PREPARATION_MESSAGES.completed;
      case "teacher_hydration_partial":
        return PREPARATION_MESSAGES.teacherPartial;
      case "teacher_hydration_item_cap":
        return PREPARATION_MESSAGES.teacherCap;
      case "cancelled":
        return PREPARATION_MESSAGES.cancelled;
      case "course_list_incomplete":
        return PREPARATION_MESSAGES.listIncomplete;
      /*
       * The two filter refusals, kept apart. Both mean nothing was prepared, but they are different facts — the page has no filter to operate versus the filter did
       * not take — and a user deciding what to do next needs to know which.
       */
      case "availability_filter_unavailable":
        return PREPARATION_MESSAGES.filterUnavailable;
      case "availability_filter_failed":
        return PREPARATION_MESSAGES.filterFailed;
      case "read_failed":
        return PREPARATION_MESSAGES.readFailed;
      default:
        return PREPARATION_MESSAGES.failed;
    }
  }
  function finalPageText(finalPage) {
    if (finalPage === void 0) return null;
    const rowCount = finalPage.rowCount;
    if (typeof rowCount !== "number" || !Number.isFinite(rowCount)) return null;
    return `\u6700\u7EC8\u8BFB\u53D6\u5230 ${rowCount} \u6761\u6559\u5B66\u73ED\u8BB0\u5F55`;
  }
  async function readActiveTabId() {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const first = Array.isArray(tabs) ? tabs[0] : void 0;
      const id = first?.id;
      return typeof id === "number" && Number.isInteger(id) ? id : null;
    } catch {
      return null;
    }
  }
  function numberField(source, key) {
    const value = source?.[key];
    return typeof value === "number" && Number.isFinite(value) ? value : void 0;
  }
  function createFullPreparationController(options) {
    const { onView } = options;
    const queryActiveTabId = options.queryActiveTabId ?? readActiveTabId;
    const sendMessage = options.sendMessage ?? ((message2) => chrome.runtime.sendMessage(message2));
    let operationTabId = null;
    let phase = "idle";
    let clicks = 0;
    let hydration = null;
    let finalRowCount = null;
    let finalListPresent = null;
    let finishedStopReason = null;
    let message = null;
    function buildView() {
      return {
        phase,
        canStart: phase === "idle" || phase === "finished" || phase === "error",
        // Cancellable during the FILTER too: the run's first phase performs page interactions, so a user who changes their mind must be able to stop it before it
        // reaches the load-more it has not been shown yet.
        canCancel: phase === "starting" || phase === "filtering_available" || phase === "loading_courses" || phase === "hydrating_teachers" || phase === "rescanning",
        clicks,
        hydration,
        finalRowCount,
        finalListPresent,
        stopReason: finishedStopReason,
        message
      };
    }
    function publish() {
      onView(buildView());
    }
    publish();
    function set(next, text) {
      phase = next;
      message = text;
      publish();
    }
    function applyStatus(status) {
      const reportedPhase = status.phase;
      absorbReports(status);
      if (reportedPhase === "filtering_available" || reportedPhase === "loading_courses" || reportedPhase === "hydrating_teachers" || reportedPhase === "rescanning") {
        phase = reportedPhase;
        message = preparationProgressText(phase, clicks, hydration);
        publish();
        return;
      }
      if (reportedPhase === "idle") {
        set("idle", null);
        return;
      }
      finishedStopReason = typeof status.stopReason === "string" ? status.stopReason : null;
      set("finished", preparationFinishText(status.stopReason));
    }
    function absorbReports(source) {
      const autoExpand = source.autoExpandStatus;
      if (autoExpand !== null && typeof autoExpand === "object") {
        const reportedClicks = numberField(autoExpand, "clicks");
        if (reportedClicks !== void 0) clicks = reportedClicks;
      }
      const reportedHydration = source.teacherHydrationStatus;
      if (reportedHydration !== null && typeof reportedHydration === "object") {
        const record = reportedHydration;
        hydration = {
          queued: numberField(record, "queued"),
          considered: numberField(record, "considered"),
          attempted: numberField(record, "attempted"),
          hydrated: numberField(record, "hydrated"),
          failed: numberField(record, "failed"),
          skipped: numberField(record, "skipped"),
          hydrationClicks: numberField(record, "hydrationClicks"),
          stopReason: typeof record.stopReason === "string" ? record.stopReason : void 0
        };
      }
      const reportedFinal = source.finalPage;
      if (reportedFinal !== null && typeof reportedFinal === "object") {
        const record = reportedFinal;
        const rowCount = numberField(record, "rowCount");
        finalRowCount = rowCount === void 0 ? null : rowCount;
        finalListPresent = typeof record.listPresent === "boolean" ? record.listPresent : null;
      }
    }
    return {
      async start() {
        if (phase === "starting" || phase === "loading_courses" || phase === "hydrating_teachers" || phase === "rescanning") return;
        const tabId = await queryActiveTabId();
        if (tabId === null) {
          set("error", PREPARATION_MESSAGES.failed);
          return;
        }
        operationTabId = tabId;
        clicks = 0;
        hydration = null;
        finalRowCount = null;
        finalListPresent = null;
        finishedStopReason = null;
        set("starting", PREPARATION_MESSAGES.starting);
        let response;
        try {
          response = await sendMessage({ type: PREPARATION_START_MESSAGE, tabId });
        } catch {
          set("error", PREPARATION_MESSAGES.failed);
          return;
        }
        const record = typeof response === "object" && response !== null ? response : {};
        if (record.ok !== true) {
          set("error", typeof record.error === "string" ? record.error : PREPARATION_MESSAGES.failed);
          return;
        }
        const reply = typeof record.reply === "object" && record.reply !== null ? record.reply : {};
        const status = typeof reply.status === "object" && reply.status !== null ? reply.status : {};
        if (reply.accepted === false) {
          const reportedPhase = status.phase;
          if (reportedPhase === "loading_courses" || reportedPhase === "hydrating_teachers" || reportedPhase === "rescanning" || reportedPhase === "finished") {
            applyStatus(status);
            return;
          }
          set("error", PREPARATION_MESSAGES.failed);
          return;
        }
        applyStatus(status);
      },
      async cancel() {
        if (phase !== "starting" && phase !== "loading_courses" && phase !== "hydrating_teachers" && phase !== "rescanning") return;
        const tabId = await queryActiveTabId();
        if (tabId === null || tabId !== operationTabId) return;
        try {
          await sendMessage({ type: PREPARATION_CANCEL_MESSAGE, tabId });
        } catch {
          return;
        }
      },
      async restore() {
        const tabId = await queryActiveTabId();
        if (tabId === null) return;
        let response;
        try {
          response = await sendMessage({ type: PREPARATION_STATUS_MESSAGE, tabId });
        } catch {
          return;
        }
        const record = typeof response === "object" && response !== null ? response : {};
        if (record.ok !== true) return;
        const reply = typeof record.reply === "object" && record.reply !== null ? record.reply : {};
        const status = reply.status;
        if (typeof status !== "object" || status === null) return;
        operationTabId = tabId;
        applyStatus(status);
      },
      onEvent(tabId, event) {
        if (tabId === null || operationTabId === null || tabId !== operationTabId) return;
        const phaseChanged = event.phase_changed;
        if (typeof phaseChanged === "string") {
          absorbReports(event);
          if (phaseChanged === "filtering_available" || phaseChanged === "loading_courses" || phaseChanged === "hydrating_teachers" || phaseChanged === "rescanning") {
            phase = phaseChanged;
            message = preparationProgressText(phase, clicks, hydration);
            publish();
          }
          return;
        }
        if (event.phase === "finished") {
          applyStatus(event);
          return;
        }
        absorbReports(event);
        if (phase === "starting") phase = "filtering_available";
        message = preparationProgressText(phase, clicks, hydration);
        publish();
      },
      view: buildView,
      operationTabId: () => operationTabId
    };
  }

  // apps/extension/src/sidepanel/recommendation-request.ts
  var LOCAL_FAILURE_TEXT = "\u65E0\u6CD5\u83B7\u53D6\u63A8\u8350\uFF1A\u5F53\u524D\u6807\u7B7E\u9875\u4E0D\u53EF\u7528\u3002";
  var MALFORMED_RESPONSE_TEXT = "\u65E0\u6CD5\u83B7\u53D6\u63A8\u8350\uFF1A\u54CD\u5E94\u683C\u5F0F\u5F02\u5E38\u3002";
  function createRecommendationRequestController(options) {
    const { sink } = options;
    const queryActiveTab = options.queryActiveTab ?? (() => chrome.tabs.query({ active: true, currentWindow: true }));
    const sendMessage = options.sendMessage ?? ((message) => chrome.runtime.sendMessage(message));
    let generation = 0;
    let lastTabId = null;
    async function readActiveTabId2() {
      try {
        const tabs = await queryActiveTab();
        const first = Array.isArray(tabs) ? tabs[0] : void 0;
        const id = first?.id;
        return typeof id === "number" && Number.isInteger(id) ? id : null;
      } catch {
        return null;
      }
    }
    async function freshnessOf(myGeneration, requestTabId) {
      if (myGeneration !== generation) return "superseded";
      const activeTabNow = await readActiveTabId2();
      if (myGeneration !== generation) return "superseded";
      return activeTabNow !== null && activeTabNow === requestTabId ? "fresh" : "stale";
    }
    function publishStale(myGeneration) {
      if (myGeneration === generation) sink({ status: "stale", reason: "tab_changed" });
    }
    return {
      tabId: () => lastTabId,
      request: async (expectedTabId, preferences) => {
        generation += 1;
        const myGeneration = generation;
        let requestTabId;
        if (expectedTabId === void 0) {
          requestTabId = await readActiveTabId2();
        } else {
          requestTabId = expectedTabId;
          const activeTabNow = await readActiveTabId2();
          if (myGeneration !== generation) return;
          if (activeTabNow !== requestTabId) {
            publishStale(myGeneration);
            return;
          }
        }
        if (requestTabId === null) {
          if (myGeneration === generation) sink({ status: "error", error: LOCAL_FAILURE_TEXT });
          return;
        }
        if (myGeneration === generation) lastTabId = requestTabId;
        sink({ status: "loading" });
        let response;
        try {
          const request = {
            type: "COURSE_COPILOT_QUERY_RECOMMENDATIONS",
            tabId: requestTabId,
            ...preferences === void 0 ? {} : { preferences }
          };
          response = await sendMessage(request);
        } catch {
          const verdict2 = await freshnessOf(myGeneration, requestTabId);
          if (verdict2 === "fresh") sink({ status: "error", error: LOCAL_FAILURE_TEXT });
          if (verdict2 === "stale") publishStale(myGeneration);
          return;
        }
        const verdict = await freshnessOf(myGeneration, requestTabId);
        if (verdict === "superseded") return;
        if (verdict === "stale") {
          publishStale(myGeneration);
          return;
        }
        const answer = typeof response === "object" && response !== null ? response : null;
        if (answer === null || typeof answer.ok !== "boolean") {
          sink({ status: "error", error: MALFORMED_RESPONSE_TEXT });
          return;
        }
        if (answer.ok) {
          if (!isPageReadStatus(answer.page) || answer.result === void 0) {
            sink({ status: "error", error: MALFORMED_RESPONSE_TEXT });
            return;
          }
          sink({ status: "success", page: answer.page, result: answer.result });
          return;
        }
        sink({ status: "error", error: typeof answer.error === "string" ? answer.error : MALFORMED_RESPONSE_TEXT });
      }
    };
  }
  function isPageReadStatus(value) {
    if (typeof value !== "object" || value === null) return false;
    const record = value;
    if (record.read !== "ok" && record.read !== "unavailable" && record.read !== "malformed") return false;
    if (typeof record.rowCount !== "number" || typeof record.courseCount !== "number") return false;
    return record.completeness === "partial" || record.completeness === "complete" || record.completeness === "unknown";
  }

  // apps/extension/src/sidepanel/preparation-report-tab.ts
  function isTabId(value) {
    return typeof value === "number" && Number.isInteger(value) && value > 0;
  }
  function preparationReportTabIdOf(payload, senderTabId) {
    const record = typeof payload === "object" && payload !== null ? payload : {};
    if (isTabId(record.sourceTabId)) return record.sourceTabId;
    if (isTabId(senderTabId)) return senderTabId;
    return null;
  }

  // apps/extension/src/sidepanel/recommendation-result.ts
  var ELIGIBLE_STOP_REASONS = [
    "teacher_hydration_completed",
    "teacher_hydration_partial",
    "teacher_hydration_item_cap"
  ];
  function preparationAllowsRecommendation(stopReason) {
    return typeof stopReason === "string" && ELIGIBLE_STOP_REASONS.includes(stopReason);
  }
  function preparationNeedsTeacherDisclosure(stopReason) {
    return stopReason === "teacher_hydration_partial" || stopReason === "teacher_hydration_item_cap";
  }
  var RECOMMENDATION_MESSAGES = {
    idle: "",
    loading: "\u6B63\u5728\u751F\u6210\u8BFE\u7A0B\u63A8\u8350\u2026",
    error: "\u751F\u6210\u63A8\u8350\u5931\u8D25\u3002",
    /** A tab change, and nothing else. See {@link STALE_TEXT}. */
    stale: "\u4E0A\u4E00\u6B21\u6570\u636E\u51C6\u5907\u4EFB\u52A1\u5BF9\u5E94\u7684\u6807\u7B7E\u9875\u5DF2\u53D8\u5316\uFF0C\u672A\u663E\u793A\u8FD9\u6B21\u63A8\u8350\u7ED3\u679C\u3002",
    /** The page the request was about is not one this extension operates on. */
    pageUnsupported: "\u5F53\u524D\u6807\u7B7E\u9875\u4E0D\u662F\u652F\u6301\u7684 WHU \u9009\u8BFE\u9875\u9762\u3002",
    /** Nothing answered: no content script, or the message was rejected. */
    pageUnavailable: "\u6682\u65F6\u65E0\u6CD5\u8BFB\u53D6\u5F53\u524D\u9009\u8BFE\u9875\u9762\u3002",
    /** Something answered, but not in the agreed shape. */
    pageMalformed: "\u5F53\u524D\u9009\u8BFE\u9875\u9762\u7ED3\u6784\u65E0\u6CD5\u6B63\u5E38\u8BFB\u53D6\u3002",
    /** A successful read that found no teaching-class rows at all. */
    pageNoRows: "\u5F53\u524D\u6CA1\u6709\u53EF\u7528\u4E8E\u63A8\u8350\u7684\u6559\u5B66\u73ED\u8BB0\u5F55\u3002",
    /** Rows were read but none became a course: a mapping problem, not an empty page. */
    pageUnmappable: "\u5DF2\u8BFB\u53D6\u6559\u5B66\u73ED\u8BB0\u5F55\uFF0C\u4F46\u6682\u65F6\u65E0\u6CD5\u8F6C\u6362\u4E3A\u53EF\u63A8\u8350\u8BFE\u7A0B\u3002",
    /** The review source answered and had nothing. This is NOT an outage. */
    reviewFoundNothing: "\u516C\u5F00\u8BFE\u7A0B\u8BC4\u4EF7\u67E5\u8BE2\u6210\u529F\uFF0C\u4F46\u672A\u627E\u5230\u5339\u914D\u8BC4\u4EF7\u3002",
    /** Some queries failed while others succeeded; the data is used but incomplete. */
    reviewPartial: "\u90E8\u5206\u516C\u5F00\u8BFE\u7A0B\u8BC4\u4EF7\u6682\u65F6\u4E0D\u53EF\u7528\uFF0C\u7ED3\u679C\u57FA\u4E8E\u5DF2\u83B7\u53D6\u7684\u6570\u636E\u3002",
    /** No query obtained an answer. */
    reviewUnavailable: "\u516C\u5F00\u8BFE\u7A0B\u8BC4\u4EF7\u6E90\u6682\u65F6\u4E0D\u53EF\u7528\u3002",
    /** A partial preparation, kept visible for as long as it is true. */
    teacherPartial: "\u6559\u5E08\u4FE1\u606F\u672A\u5B8C\u5168\u8865\u5168\uFF0C\u63A8\u8350\u57FA\u4E8E\u5F53\u524D\u5DF2\u83B7\u53D6\u7684\u6570\u636E\u3002",
    /** The ranking is empty but courses were rated — a cut, not a data failure. */
    emptyButRated: "\u5F53\u524D\u6709\u8BC4\u4EF7\u6570\u636E\uFF0C\u4F46\u6CA1\u6709\u8BFE\u7A0B\u8FDB\u5165\u63A8\u8350\u7ED3\u679C\u3002",
    /** Nothing was rated and nothing was recommended, because the evidence is thin. */
    emptyInsufficient: "\u5F53\u524D\u8BFE\u7A0B\u8BC4\u4EF7\u8BC1\u636E\u4E0D\u8DB3\uFF0C\u6682\u65F6\u65E0\u6CD5\u5F62\u6210\u63A8\u8350\u3002",
    /** The ranking is empty for a reason none of the specific sentences covers. */
    emptyOtherwise: "\u5F53\u524D\u6CA1\u6709\u5F97\u5230\u53EF\u5C55\u793A\u7684\u63A8\u8350\u7ED3\u679C\u3002",
    /** The preparation did not finish, so no recommendation was attempted. */
    preparationIncomplete: "\u6570\u636E\u51C6\u5907\u672A\u5B8C\u6210\uFF0C\u56E0\u6B64\u672A\u751F\u6210\u63A8\u8350\u3002"
  };
  var RECOMMENDATION_LABELS = {
    recommended: "\u63A8\u8350\u8BFE\u7A0B",
    rated: "\u6709\u8BC4\u4EF7\u4F46\u672A\u8FDB\u5165\u63A8\u8350",
    insufficient: "\u8BC1\u636E\u4E0D\u8DB3"
  };
  function countOf(source, key) {
    const value = source[key];
    return typeof value === "number" && Number.isFinite(value) ? value : void 0;
  }
  function pageNoticeFor(page) {
    if (page.supported === false) return RECOMMENDATION_MESSAGES.pageUnsupported;
    const read = page.read;
    if (read === "unavailable") return RECOMMENDATION_MESSAGES.pageUnavailable;
    if (read === "malformed") return RECOMMENDATION_MESSAGES.pageMalformed;
    if (read !== "ok") return RECOMMENDATION_MESSAGES.pageUnavailable;
    const rowCount = countOf(page, "rowCount");
    const courseCount = countOf(page, "courseCount");
    if (rowCount === 0) return RECOMMENDATION_MESSAGES.pageNoRows;
    if (rowCount !== void 0 && courseCount === 0) return RECOMMENDATION_MESSAGES.pageUnmappable;
    return null;
  }
  function reviewNoticeFor(reviewSource) {
    if (typeof reviewSource !== "object" || reviewSource === null) return null;
    const health = reviewSource;
    const status = health.status;
    if (status === "partial") return RECOMMENDATION_MESSAGES.reviewPartial;
    if (status === "unavailable") return RECOMMENDATION_MESSAGES.reviewUnavailable;
    if (status !== "healthy") return null;
    const queries = countOf(health, "queries");
    const rows = countOf(health, "rows");
    const empty = countOf(health, "empty");
    const unavailable = countOf(health, "unavailable");
    if ((queries ?? 0) > 0 && rows === 0 && (empty ?? 0) > 0 && (unavailable ?? 0) === 0) {
      return RECOMMENDATION_MESSAGES.reviewFoundNothing;
    }
    return null;
  }
  function emptyNoticeFor(recommended, rated, insufficient) {
    if (recommended > 0) return null;
    if (rated > 0) return RECOMMENDATION_MESSAGES.emptyButRated;
    if (insufficient > 0) return RECOMMENDATION_MESSAGES.emptyInsufficient;
    return RECOMMENDATION_MESSAGES.emptyOtherwise;
  }
  function recommendationIdleView(preparationStopReason, hasPreparation) {
    const stopped = hasPreparation && !preparationAllowsRecommendation(preparationStopReason);
    return {
      status: "idle",
      message: stopped ? RECOMMENDATION_MESSAGES.preparationIncomplete : RECOMMENDATION_MESSAGES.idle,
      pageNotice: null,
      reviewNotice: null,
      teacherNotice: null,
      counts: null,
      emptyNotice: null
    };
  }
  function recommendationResultView(state, preparationStopReason) {
    if (state.status === "stale") {
      return {
        status: "stale",
        message: RECOMMENDATION_MESSAGES.stale,
        pageNotice: null,
        reviewNotice: null,
        teacherNotice: null,
        counts: null,
        emptyNotice: null
      };
    }
    if (state.status === "error") {
      return {
        status: "error",
        message: RECOMMENDATION_MESSAGES.error,
        pageNotice: null,
        reviewNotice: null,
        teacherNotice: null,
        counts: null,
        emptyNotice: null
      };
    }
    const teacherNotice = preparationNeedsTeacherDisclosure(preparationStopReason) ? RECOMMENDATION_MESSAGES.teacherPartial : null;
    if (state.status === "loading") {
      return {
        status: "loading",
        message: RECOMMENDATION_MESSAGES.loading,
        pageNotice: null,
        reviewNotice: null,
        teacherNotice,
        counts: null,
        emptyNotice: null
      };
    }
    const page = state.page;
    const pageNotice = pageNoticeFor(page);
    if (pageNotice !== null) {
      return {
        status: "success",
        message: "",
        pageNotice,
        /*
         * The review disclosure is still shown beside a page notice: the page explains why there is no ranking, and the source explains what the run learned while
         * trying. It is the same run.
         */
        reviewNotice: reviewNoticeFor(state.result.reviewSource),
        teacherNotice,
        counts: null,
        emptyNotice: null
      };
    }
    const result = state.result;
    const recommended = Array.isArray(result.recommendations) ? result.recommendations.length : 0;
    const rated = Array.isArray(result.ratedButNotRecommended) ? result.ratedButNotRecommended.length : 0;
    const insufficient = Array.isArray(result.insufficientData) ? result.insufficientData.length : 0;
    return {
      status: "success",
      message: "",
      pageNotice: null,
      reviewNotice: reviewNoticeFor(result.reviewSource),
      teacherNotice,
      // Three separate numbers, never merged: a course rated below the cut and a course with no usable evidence are different answers.
      counts: { recommended, rated, insufficient },
      emptyNotice: emptyNoticeFor(recommended, rated, insufficient)
    };
  }
  function createRecommendationHandoff(options) {
    let startedForThisPreparation = false;
    return {
      reset() {
        startedForThisPreparation = false;
      },
      consider(phase, stopReason, operationTabId) {
        if (phase !== "finished") return;
        if (!preparationAllowsRecommendation(stopReason)) return;
        if (operationTabId === null) return;
        if (startedForThisPreparation) return;
        startedForThisPreparation = true;
        void options.request(operationTabId);
      }
    };
  }

  // apps/extension/src/sidepanel/course-presentation.ts
  var GRADE_DISCLAIMER = "\u5B66\u751F\u8BC4\u4EF7\u4E2D\u7684\u81EA\u62A5\u6210\u7EE9\u7EDF\u8BA1\uFF0C\u4E0D\u662F\u6B66\u6C49\u5927\u5B66\u5B98\u65B9\u8BFE\u7A0B\u5E73\u5747\u6210\u7EE9";
  var TEACHER_NOT_PUBLISHED_TEXT = "\u4EFB\u8BFE\u8001\u5E08\uFF1A\u5C1A\u672A\u52A0\u8F7D/\u9875\u9762\u672A\u63D0\u4F9B";
  function teacherText(course) {
    return typeof course.teacher === "string" && course.teacher.length > 0 ? course.teacher : null;
  }
  var CONFIDENCE_TIER_TEXT = {
    low: "\u4F4E",
    medium: "\u4E2D",
    high: "\u9AD8"
  };
  var ASPECT_TEXT = {
    gradeFriendliness: "\u6210\u7EE9\u53CB\u597D\u5EA6",
    workloadFriendliness: "\u5DE5\u4F5C\u91CF\u53CB\u597D\u5EA6",
    attendanceFriendliness: "\u8003\u52E4\u53CB\u597D\u5EA6",
    examFriendliness: "\u8003\u6838\u53CB\u597D\u5EA6",
    teachingQuality: "\u6559\u5B66\u8D28\u91CF",
    studentSentiment: "\u5B66\u751F\u8BC4\u4EF7"
  };
  function aspectText(aspect) {
    return ASPECT_TEXT[aspect] ?? aspect;
  }
  var EVIDENCE_LEVEL_TEXT = {
    strong: "\u5145\u5206",
    moderate: "\u4E2D\u7B49",
    limited: "\u504F\u5C11",
    none: "\u65E0"
  };
  var HYDRATABLE_FIELD_TEXT = {
    teacher: "\u4EFB\u8BFE\u8001\u5E08",
    schedule: "\u4E0A\u8BFE\u65F6\u95F4",
    location: "\u4E0A\u8BFE\u5730\u70B9",
    department: "\u5F00\u8BFE\u9662\u7CFB",
    capacity: "\u5BB9\u91CF"
  };
  var HYDRATION_STATUS_TEXT = {
    full: "\u8BFE\u7A0B\u8BE6\u60C5\u5DF2\u52A0\u8F7D",
    basic: "\u4EC5\u8BFB\u53D6\u5230\u5217\u8868\u884C"
  };
  var REVIEW_SCOPE_TEXT = {
    teacher: "\u5F53\u524D\u6559\u5E08\u8BC4\u4EF7\u8BC1\u636E",
    course: "\u8BFE\u7A0B\u6574\u4F53\u8BC4\u4EF7\u8BC1\u636E"
  };
  var REVIEW_LABEL_TEXT = {
    /** Joins several names the way the rest of the panel does. */
    nameSeparator: "\u3001",
    /** Prefix for anything that is NOT this class's own evidence. */
    courseReferencePrefix: "\u8BFE\u7A0B\u6574\u4F53\u53C2\u8003",
    /** Suffix naming the teachers a course-level comment mentioned. */
    teacherSuffix: "\u6559\u5E08",
    /** Used when a course-level comment names nobody, OR when it is supplementary. */
    teacherUnknown: "\u6559\u5E08\u4FE1\u606F\u672A\u660E\u786E",
    /** Assembled form: `课程整体参考 · 教师：王五`. */
    referenceWithTeachers: (names) => `${REVIEW_LABEL_TEXT.courseReferencePrefix} \xB7 ${REVIEW_LABEL_TEXT.teacherSuffix}\uFF1A${names}`,
    /** Assembled form: `课程整体参考 · 教师信息未明确`. */
    referenceWithoutTeachers: () => `${REVIEW_LABEL_TEXT.courseReferencePrefix} \xB7 ${REVIEW_LABEL_TEXT.teacherUnknown}`
  };
  function reviewExcerptLabelOf(excerpt) {
    if (excerpt.scope === "current_class") {
      const names = excerpt.teacherNames.filter((name) => name.trim().length > 0);
      if (names.length > 0) return names.join(REVIEW_LABEL_TEXT.nameSeparator);
      return REVIEW_LABEL_TEXT.referenceWithoutTeachers();
    }
    if (excerpt.scope === "course_reference") {
      const names = excerpt.teacherNames.filter((name) => name.trim().length > 0);
      if (names.length > 0) return REVIEW_LABEL_TEXT.referenceWithTeachers(names.join(REVIEW_LABEL_TEXT.nameSeparator));
    }
    return REVIEW_LABEL_TEXT.referenceWithoutTeachers();
  }
  function reviewExcerptsOf(excerpts) {
    return excerpts.map((excerpt) => ({ text: excerpt.text, label: reviewExcerptLabelOf(excerpt) }));
  }
  var COURSE_STATUS_TEXT = {
    rated: "\u6709\u8BC4\u4EF7\uFF0C\u4F46\u672A\u8FDB\u5165\u63A8\u8350\u7ED3\u679C",
    insufficient: "\u8BC4\u4EF7\u8BC1\u636E\u4E0D\u8DB3\uFF0C\u6682\u4E0D\u505A\u63A8\u8350\u5224\u65AD"
  };
  function identityOf(course) {
    return {
      courseName: course.courseName,
      teacher: teacherText(course),
      teacherFallback: TEACHER_NOT_PUBLISHED_TEXT,
      courseCode: typeof course.courseCode === "string" && course.courseCode.length > 0 ? course.courseCode : null,
      // Absent stays absent: `0` would claim a credit value the page never stated.
      credits: typeof course.credits === "number" && Number.isFinite(course.credits) ? course.credits : null,
      /*
       * `0` is preserved as `0` and never folded into "missing". A `!remainingSeats` test here is the classic version of this bug, and it turns a full course
       * into an unknown one.
       */
      remainingSeats: typeof course.remainingSeats === "number" && Number.isFinite(course.remainingSeats) ? course.remainingSeats : null,
      /*
       * The second seat fact, carried with the SAME rule and for the same reason: `0` here means "nobody has signed up yet", which is a real answer, so a
       * truthiness test would erase it. Nothing is derived from it — no ratio against the remaining seats, no tier, no comparison — because the raw fact is all
       * this mapper is allowed to transport.
       */
      selectedThisRound: typeof course.selectedThisRound === "number" && Number.isFinite(course.selectedThisRound) ? course.selectedThisRound : null,
      availability: course.availability
    };
  }
  function reviewContextOf(context) {
    return {
      scope: context.scope,
      // The two scopes are not interchangeable claims, so each gets its own sentence.
      scopeText: REVIEW_SCOPE_TEXT[context.scope],
      reviewCount: context.reviewCount,
      teacherSpecified: context.teacherSpecified,
      teacher: context.teacher,
      teacherMatchConfidence: context.teacherMatchConfidence,
      aggregationNote: context.aggregationNote
    };
  }
  function sectionHydrationOf(hydration) {
    return {
      status: hydration.status,
      statusText: HYDRATION_STATUS_TEXT[hydration.status],
      available: hydration.available.map((field) => HYDRATABLE_FIELD_TEXT[field]),
      missing: hydration.missing.map((field) => HYDRATABLE_FIELD_TEXT[field]),
      rawHydrated: hydration.rawHydrated
    };
  }
  function primaryGradeOf(aggregates, teacherCount) {
    if (teacherCount === 1 && aggregates.teacher !== void 0) return { scope: "teacher", grade: aggregates.teacher };
    if (teacherCount > 1 && aggregates.teachingClass !== void 0) return { scope: "teachingClass", grade: aggregates.teachingClass };
    return { scope: null, grade: null };
  }
  function gradePresentationOf(aggregates) {
    const names = aggregates.teacherSet.names;
    const primary = primaryGradeOf(aggregates, names.length);
    return {
      primaryScope: primary.scope,
      primaryGrade: primary.grade,
      courseGrade: aggregates.course ?? null,
      /*
       * The corpus's own teacher names, carried for reference ONLY. They are never a substitute for the page's teacher text: one is what the review site indexed and
       * the other is what the selection page published, and they can legitimately differ.
       */
      teacherSetNames: [...names],
      disclaimer: GRADE_DISCLAIMER
    };
  }
  function toRecommendedCoursePresentation(recommendation) {
    return {
      kind: "recommended",
      ...identityOf(recommendation.course),
      rank: recommendation.rank,
      // Score and confidence are carried as two separate facts, each with its own field.
      score: recommendation.score,
      confidence: {
        value: recommendation.confidence.value,
        tier: recommendation.confidence.tier,
        tierText: CONFIDENCE_TIER_TEXT[recommendation.confidence.tier]
      },
      /*
       * Per aspect, one entry each. No overall level is computed: taking a minimum, a maximum or an average across aspects would be a number the engine never
       * produced, and the canonical type has no such field.
       */
      evidenceStrength: recommendation.evidenceStrength.map((entry) => ({
        aspect: entry.aspect,
        aspectText: aspectText(entry.aspect),
        level: entry.level,
        levelText: EVIDENCE_LEVEL_TEXT[entry.level],
        reviewsWithEvidence: entry.reviewsWithEvidence,
        corpusReviews: entry.corpusReviews,
        note: entry.note
      })),
      grade: gradePresentationOf(recommendation.gradeAggregates),
      reviewExcerpts: reviewExcerptsOf(recommendation.reviewExcerpts),
      reviewContext: reviewContextOf(recommendation.reviewContext),
      sectionHydration: sectionHydrationOf(recommendation.sectionHydration),
      reviewSource: recommendation.reviewSource,
      reasons: [...recommendation.reasons],
      warnings: [...recommendation.warnings]
    };
  }
  function toRatedCoursePresentation(entry) {
    return {
      kind: "ratedButNotRecommended",
      ...identityOf(entry.course),
      rank: entry.rank,
      score: entry.score,
      statusText: COURSE_STATUS_TEXT.rated,
      reviewContext: reviewContextOf(entry.reviewContext),
      sectionHydration: sectionHydrationOf(entry.sectionHydration),
      grade: gradePresentationOf(entry.gradeAggregates),
      reviewExcerpts: reviewExcerptsOf(entry.reviewExcerpts)
    };
  }
  function toInsufficientCoursePresentation(entry) {
    return {
      kind: "insufficientData",
      ...identityOf(entry.course),
      statusText: COURSE_STATUS_TEXT.insufficient,
      reason: entry.reason,
      match: { method: entry.match.method, confidence: entry.match.confidence },
      reviewSource: entry.reviewSource
    };
  }

  // apps/extension/src/sidepanel/course-cards.ts
  var CARD_TEXT = {
    /** The area's own title, which claims a snapshot rather than live state. */
    title: "\u63A8\u8350\u5FEB\u7167",
    sections: {
      recommended: "\u63A8\u8350\u8BFE\u7A0B",
      rated: "\u6709\u8BC4\u4EF7\uFF0C\u4F46\u672A\u8FDB\u5165\u63A8\u8350",
      insufficient: "\u8BC4\u4EF7\u8BC1\u636E\u4E0D\u8DB3"
    },
    teacher: "\u4EFB\u8BFE\u8001\u5E08",
    courseCode: "\u8BFE\u7A0B\u4EE3\u7801",
    credits: "\u5B66\u5206",
    /** Shown when the page stated no credits. Never a zero credit value. */
    creditsUnknown: "\u5B66\u5206\uFF1A\u6682\u65E0\u6570\u636E",
    remainingSeats: "\u4F59\u91CF",
    /** A zero seat count is a fact about a full course, and is labelled as one. */
    seatsFull: "\u4F59\u91CF\uFF1A0\uFF08\u5DF2\u6EE1\uFF09",
    seatsUnknown: "\u4F59\u91CF\uFF1A\u672A\u77E5",
    /**
     * How many students had already signed up in this round — the page's own 「本轮已选」.
     *
     * The label is the school's own wording, and the label is the whole point: any synonym that dropped the round, or that described the course's popularity instead of a
     * count of sign-ups, would state something the page never published. The specific rejected synonyms are named in `step42SelectedThisRoundPresentation.test.ts`
     * rather than here, because this comment is preserved into the shipped bundle and a reader scanning the artifact for a forbidden label must not find one in prose.
     */
    selectedThisRound: "\u672C\u8F6E\u5DF2\u9009",
    /** A zero here means nobody has signed up YET — a real answer, said as `0` rather than as unknown. */
    selectedThisRoundUnknown: "\u672C\u8F6E\u5DF2\u9009\uFF1A\u672A\u77E5",
    /** The admission status, as three separate words plus the label they hang off. */
    availabilityLabel: "\u53EF\u9009\u72B6\u6001",
    availabilityAvailable: "\u6709\u4F59\u91CF",
    availabilityFull: "\u5DF2\u6EE1",
    availabilityUnknown: "\u72B6\u6001\u672A\u77E5",
    rank: "\u63A8\u8350\u6392\u540D",
    rankPrefix: "#",
    score: "\u63A8\u8350\u5206",
    confidence: "\u7F6E\u4FE1\u5EA6",
    evidence: "\u8BC1\u636E",
    reviewScope: {
      teacher: "\u8BC4\u4EF7\u8303\u56F4\uFF1A\u5F53\u524D\u6559\u5E08",
      course: "\u8BC4\u4EF7\u8303\u56F4\uFF1A\u8BFE\u7A0B\u6574\u4F53"
    },
    reviewCount: "\u8BC4\u4EF7\u6837\u672C",
    /**
     * The self-reported grade line, rendered as ONE row per course.
     *
     * PRE-RELEASE-UX-A12 replaced a block of seven or eight rows — a scope heading, an average, a sample count, then the same three again for the whole-course
     * reference, then per-card boilerplate — with a single sentence. The SCOPE survives, because a teaching-class average and a whole-course average are different
     * claims and the frozen rule forbids presenting one as the other; what is gone is the repetition, not the qualification.
     *
     * The three scope labels are distinct on purpose and `course` is named 参考 so a reader cannot mistake the whole-course figure for this class's own.
     */
    grade: {
      /** The single label on every grade row. */
      label: "\u5B66\u751F\u81EA\u62A5\u5E73\u5747\u6210\u7EE9",
      /** Shown when no aggregate carries a usable mean. */
      unavailable: "\u6682\u65E0\u6570\u636E",
      scope: {
        teacher: "\u5F53\u524D\u6559\u5E08",
        teachingClass: "\u5F53\u524D\u6559\u5B66\u73ED",
        course: "\u8BFE\u7A0B\u6574\u4F53\u53C2\u8003"
      }
    },
    reviewSource: {
      healthy: null,
      partial: "\u90E8\u5206\u8BC4\u4EF7\u6570\u636E\u6682\u65F6\u4E0D\u53EF\u7528",
      unavailable: "\u8BE5\u8BFE\u7A0B\u516C\u5F00\u8BC4\u4EF7\u6682\u65F6\u4E0D\u53EF\u7528"
    },
    /**
     * The collapsible student-review module.
     *
     * PRE-RELEASE-UX-A17. The count is appended from the number of excerpts actually rendered, so the heading cannot promise more than the list
     * holds; the parentheses are full-width because the rest of this panel's counts are.
     */
    reviews: {
      /** The disclosure heading, before its count. */
      buttonLabel: "\u67E5\u770B\u5B66\u751F\u8BC4\u4EF7",
      /** The count, in the panel's own punctuation. */
      countSuffix: (count) => `\uFF08${count}\uFF09`
    },
    insufficientReviewSource: {
      healthy: null,
      partial: "\u90E8\u5206\u516C\u5F00\u8BC4\u4EF7\u6682\u65F6\u4E0D\u53EF\u7528",
      unavailable: "\u516C\u5F00\u8BC4\u4EF7\u6E90\u6682\u65F6\u4E0D\u53EF\u7528"
    },
    /** The matcher's number, named so it cannot be read as a recommendation confidence. */
    matchConfidence: "\u8BC4\u4EF7\u5339\u914D\u7F6E\u4FE1",
    matchMethod: "\u5339\u914D\u65B9\u5F0F",
    /**
     * The ONE interpretation this panel makes, and the only place it states a judgement rather than a page fact.
     *
     * It describes a comparison a reader can verify from the two rows directly above it: this round's sign-ups already exceed the places
     * that were free entering the round. It says nothing about the OUTCOME — the last clause hands that back to the selection system —
     * and the second sentence states outright that it is not a probability. Both halves are required: a warning asserting a risk without
     * that caveat would be claiming a prediction nobody made.
     */
    competitionWarning: "\u7ADE\u4E89\u8F83\u9AD8\uFF1A\u672C\u8F6E\u5DF2\u9009\u4EBA\u6570\u5DF2\u8D85\u8FC7\u672C\u8F6E\u4F59\u91CF\uFF0C\u6700\u7EC8\u7ED3\u679C\u4ECD\u4EE5\u9009\u8BFE\u7CFB\u7EDF\u4E3A\u51C6\u3002",
    competitionWarningNote: "\u6B64\u63D0\u793A\u4EC5\u53CD\u6620\u5F53\u524D\u4EBA\u6570\u4E0E\u4F59\u91CF\u5173\u7CFB\uFF0C\u4E0D\u4EE3\u8868\u9009\u4E2D\u6982\u7387\u3002"
  };
  function fact(label, value, kind) {
    const row = document.createElement("p");
    row.className = kind === void 0 ? "course-card-fact" : `course-card-fact course-card-${kind}`;
    const labelSpan = document.createElement("span");
    labelSpan.className = "course-card-label";
    labelSpan.textContent = `${label}\uFF1A`;
    const valueSpan = document.createElement("span");
    valueSpan.className = "course-card-value";
    valueSpan.textContent = value;
    row.append(labelSpan, valueSpan);
    return row;
  }
  function shell(kindClass, title, statusText) {
    const card = document.createElement("li");
    card.className = `course-card ${kindClass}`;
    const heading = document.createElement("p");
    heading.className = "course-card-title";
    heading.textContent = title;
    const status = document.createElement("p");
    status.className = "course-card-status";
    status.textContent = statusText;
    const body = document.createElement("div");
    body.className = "course-card-body";
    card.append(heading, status, body);
    return { card, body };
  }
  function appendIdentity(body, presentation) {
    body.append(fact(
      CARD_TEXT.teacher,
      presentation.teacher ?? presentation.teacherFallback.replace(/^[^：]*：/u, "")
    ));
    if (presentation.courseCode !== null) body.append(fact(CARD_TEXT.courseCode, presentation.courseCode));
    body.append(presentation.credits === null ? textRow(CARD_TEXT.creditsUnknown) : fact(CARD_TEXT.credits, String(presentation.credits)));
    if (presentation.remainingSeats === 0) body.append(textRow(CARD_TEXT.seatsFull));
    else if (presentation.remainingSeats === null) body.append(textRow(CARD_TEXT.seatsUnknown));
    else body.append(fact(CARD_TEXT.remainingSeats, String(presentation.remainingSeats)));
    if (presentation.selectedThisRound === null) body.append(textRow(CARD_TEXT.selectedThisRoundUnknown));
    else body.append(fact(CARD_TEXT.selectedThisRound, String(presentation.selectedThisRound)));
    body.append(fact(CARD_TEXT.availabilityLabel, availabilityText(presentation.availability)));
    appendCompetitionWarning(body, presentation);
  }
  function availabilityText(availability) {
    if (availability === "available") return CARD_TEXT.availabilityAvailable;
    if (availability === "full") return CARD_TEXT.availabilityFull;
    return CARD_TEXT.availabilityUnknown;
  }
  function isOversubscribed(presentation) {
    if (presentation.remainingSeats === null || presentation.selectedThisRound === null) return false;
    return presentation.selectedThisRound > presentation.remainingSeats;
  }
  function appendCompetitionWarning(body, presentation) {
    if (!isOversubscribed(presentation)) return;
    const block = document.createElement("div");
    block.className = "course-card-competition-warning";
    const primary = document.createElement("p");
    primary.className = "course-card-competition-warning-primary";
    primary.textContent = CARD_TEXT.competitionWarning;
    const note = document.createElement("p");
    note.className = "course-card-competition-warning-note";
    note.textContent = CARD_TEXT.competitionWarningNote;
    block.append(primary, note);
    body.append(block);
  }
  function textRow(text) {
    const row = document.createElement("p");
    row.className = "course-card-fact";
    row.textContent = text;
    return row;
  }
  function appendReviewContext(body, context) {
    body.append(textRow(context.scopeText));
    body.append(fact(CARD_TEXT.reviewCount, String(context.reviewCount)));
  }
  function appendEvidence(body, evidence) {
    for (const entry of evidence) {
      body.append(fact(entry.aspectText, `${CARD_TEXT.evidence}${entry.levelText}\uFF08${entry.reviewsWithEvidence}/${entry.corpusReviews}\uFF09`, "evidence"));
    }
  }
  function gradeLineOf(grade) {
    const primary = grade.primaryGrade;
    const reference = grade.courseGrade;
    const selected = typeof primary?.meanGrade === "number" && grade.primaryScope !== null ? { mean: primary.meanGrade, count: primary.gradedSampleCount, scope: grade.primaryScope } : typeof reference?.meanGrade === "number" ? { mean: reference.meanGrade, count: reference.gradedSampleCount, scope: "course" } : null;
    if (selected === null) return `${CARD_TEXT.grade.label}\uFF1A${CARD_TEXT.grade.unavailable}`;
    const scopeText = CARD_TEXT.grade.scope[selected.scope];
    return `${CARD_TEXT.grade.label}\uFF1A${selected.mean.toFixed(1)}\uFF08${selected.count}\u4EFD\uFF0C${scopeText}\uFF09`;
  }
  function appendGrade(body, grade) {
    body.append(textRow(gradeLineOf(grade)));
  }
  function appendReviewSource(body, health, wording) {
    if (health.status === "partial") body.append(textRow(wording.partial));
    if (health.status === "unavailable") body.append(textRow(wording.unavailable));
  }
  var disclosureSerial = 0;
  function appendReviewExcerpts(body, excerpts, options) {
    if (excerpts.length === 0) return;
    disclosureSerial += 1;
    const targetId = `course-review-${disclosureSerial}`;
    const module = document.createElement("div");
    module.className = "course-card-reviews";
    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.className = "course-card-reviews-toggle";
    toggle.textContent = `${options.buttonLabel}${options.countSuffix(excerpts.length)}`;
    toggle.setAttribute("aria-expanded", "false");
    toggle.setAttribute("aria-controls", targetId);
    const list = document.createElement("div");
    list.className = "course-card-reviews-list";
    list.id = targetId;
    list.hidden = true;
    for (const excerpt of excerpts) {
      const item = document.createElement("div");
      item.className = "course-card-review";
      const label = document.createElement("p");
      label.className = "course-card-review-label";
      label.textContent = excerpt.label;
      const text = document.createElement("p");
      text.className = "course-card-review-text";
      text.textContent = excerpt.text;
      item.append(label, text);
      list.append(item);
    }
    let expanded = false;
    toggle.addEventListener("click", () => {
      expanded = !expanded;
      toggle.setAttribute("aria-expanded", String(expanded));
      list.hidden = !expanded;
    });
    module.append(toggle, list);
    body.append(module);
  }
  function recommendedCard(presentation) {
    const { card, body } = shell("course-card-recommended", presentation.courseName, "\u63A8\u8350\u8BFE\u7A0B");
    appendIdentity(body, presentation);
    body.append(fact(CARD_TEXT.rank, `${CARD_TEXT.rankPrefix}${presentation.rank}`));
    body.append(presentation.score === null ? textRow(`${CARD_TEXT.score}\uFF1A\u65E0`) : fact(CARD_TEXT.score, String(presentation.score)));
    if (presentation.confidence !== null) body.append(fact(CARD_TEXT.confidence, presentation.confidence.tierText));
    appendEvidence(body, presentation.evidenceStrength);
    appendReviewContext(body, presentation.reviewContext);
    appendGrade(body, presentation.grade);
    appendReviewSource(body, presentation.reviewSource, CARD_TEXT.reviewSource);
    for (const reason of presentation.reasons) body.append(textRow(reason));
    for (const warning of presentation.warnings) body.append(textRow(warning));
    appendReviewExcerpts(body, presentation.reviewExcerpts, CARD_TEXT.reviews);
    return card;
  }
  function ratedCard(presentation) {
    const { card, body } = shell("course-card-rated", presentation.courseName, presentation.statusText);
    appendIdentity(body, presentation);
    body.append(fact(CARD_TEXT.rank, `${CARD_TEXT.rankPrefix}${presentation.rank}`));
    body.append(fact(CARD_TEXT.score, String(presentation.score)));
    appendReviewContext(body, presentation.reviewContext);
    appendGrade(body, presentation.grade);
    appendReviewExcerpts(body, presentation.reviewExcerpts, CARD_TEXT.reviews);
    return card;
  }
  function insufficientCard(presentation) {
    const { card, body } = shell("course-card-insufficient", presentation.courseName, presentation.statusText);
    appendIdentity(body, presentation);
    body.append(textRow(presentation.reason));
    body.append(fact(CARD_TEXT.matchConfidence, presentation.match.confidence.toFixed(2)));
    appendReviewSource(body, presentation.reviewSource, CARD_TEXT.insufficientReviewSource);
    return card;
  }
  function renderCourseCards(root, result) {
    root.recommended.replaceChildren();
    root.rated.replaceChildren();
    root.insufficient.replaceChildren();
    disclosureSerial = 0;
    if (result === null) {
      root.sections.recommended.hidden = true;
      root.sections.rated.hidden = true;
      root.sections.insufficient.hidden = true;
      if (root.disclaimer !== void 0) {
        root.disclaimer.textContent = "";
        root.disclaimer.hidden = true;
      }
      if (root.disclosure !== void 0) {
        root.disclosure.count.textContent = "";
      }
      return;
    }
    for (const entry of result.recommendations) root.recommended.append(recommendedCard(toRecommendedCoursePresentation(entry)));
    for (const entry of result.ratedButNotRecommended) root.rated.append(ratedCard(toRatedCoursePresentation(entry)));
    for (const entry of result.insufficientData) root.insufficient.append(insufficientCard(toInsufficientCoursePresentation(entry)));
    root.sections.recommended.hidden = result.recommendations.length === 0;
    root.sections.rated.hidden = result.ratedButNotRecommended.length === 0;
    root.sections.insufficient.hidden = result.insufficientData.length === 0;
    if (root.disclosure !== void 0) {
      root.disclosure.count.textContent = result.ratedButNotRecommended.length === 0 ? "" : `\uFF08${result.ratedButNotRecommended.length}\uFF09`;
      setRatedCollapsed(root.disclosure, true);
    }
    if (root.disclaimer !== void 0) {
      const hasCards = result.recommendations.length > 0 || result.ratedButNotRecommended.length > 0;
      root.disclaimer.textContent = hasCards ? GRADE_DISCLAIMER : "";
      root.disclaimer.hidden = !hasCards;
    }
  }
  function setRatedCollapsed(disclosure, collapsed) {
    disclosure.toggle.setAttribute("aria-expanded", String(!collapsed));
    disclosure.panel.hidden = collapsed;
  }

  // apps/extension/src/sidepanel/preferences.ts
  var PREFERENCE_CONTROLS = [
    { key: "gradeFriendliness", label: "\u6210\u7EE9\u53CB\u597D" },
    { key: "workloadFriendliness", label: "\u5DE5\u4F5C\u91CF\u8F7B\u677E" },
    { key: "attendanceFriendliness", label: "\u8003\u52E4\u5BBD\u677E" },
    { key: "overallScore", label: "\u5B66\u751F\u8BC4\u4EF7" }
  ];
  var PREFERENCE_MIN = 0;
  var PREFERENCE_MAX = 10;
  var PREFERENCE_DEFAULTS = Object.freeze({
    gradeFriendliness: 10,
    workloadFriendliness: 6,
    attendanceFriendliness: 3,
    overallScore: 1
  });
  function defaultPreferenceValues() {
    return { ...PREFERENCE_DEFAULTS };
  }
  function isUsableImportance(value) {
    return typeof value === "number" && Number.isInteger(value) && value >= PREFERENCE_MIN && value <= PREFERENCE_MAX;
  }
  var PREFERENCE_PROBLEM_TEXT = Object.freeze({
    all_zero: "\u81F3\u5C11\u6709\u4E00\u9879\u91CD\u8981\u7A0B\u5EA6\u9700\u8981\u5927\u4E8E 0\u3002",
    unusable_value: "\u504F\u597D\u503C\u5FC5\u987B\u662F 0 \u5230 10 \u4E4B\u95F4\u7684\u6574\u6570\u3002"
  });
  function preferenceProblemOf(values) {
    for (const { key } of PREFERENCE_CONTROLS) {
      if (!isUsableImportance(values[key])) return { code: "unusable_value", key };
    }
    const total = PREFERENCE_CONTROLS.reduce((sum, { key }) => sum + values[key], 0);
    return total === 0 ? { code: "all_zero" } : null;
  }
  function preferencePercentagesOf(values) {
    const total = PREFERENCE_CONTROLS.reduce((sum, { key }) => sum + (values[key] ?? 0), 0);
    if (total <= 0) return PREFERENCE_CONTROLS.map(() => 0);
    return PREFERENCE_CONTROLS.map(({ key }) => Math.round((values[key] ?? 0) / total * 100));
  }
  function preferencePayloadOf(values) {
    return {
      gradeFriendliness: values.gradeFriendliness ?? 0,
      workloadFriendliness: values.workloadFriendliness ?? 0,
      attendanceFriendliness: values.attendanceFriendliness ?? 0,
      overallScore: values.overallScore ?? 0
    };
  }

  // apps/extension/src/sidepanel/sidepanel.ts
  (() => {
    const SUPPORTED_TEXT = "\u5DF2\u8BC6\u522B WHU \u81EA\u4E3B\u9009\u8BFE\u9875\u9762";
    const UNSUPPORTED_TEXT = "\u5F53\u524D\u672A\u68C0\u6D4B\u5230\u652F\u6301\u7684 WHU \u81EA\u4E3B\u9009\u8BFE\u9875\u9762";
    const PAGE_STATUS_MESSAGE = "COURSE_COPILOT_PAGE_STATUS";
    const PANEL_COUNT_MESSAGE = "COURSE_COPILOT_PANEL_COUNT";
    const PING_MESSAGE = "COURSE_COPILOT_PING";
    const STATUS_ELEMENT_ID = "page-status";
    const COUNT_ELEMENT_ID = "panel-count";
    const VERSION_ELEMENT_ID = "fact-version";
    const PREFERENCES_PROBLEM_ELEMENT_ID = "preferences-problem";
    const PREFERENCES_RESET_ELEMENT_ID = "preferences-reset";
    const PREFERENCES_APPLY_ELEMENT_ID = "preferences-apply";
    const PREFERENCES_NO_TARGET_TEXT = "\u8BF7\u5148\u52A0\u8F7D\u8BFE\u7A0B\u5E76\u751F\u6210\u4E00\u6B21\u63A8\u8350\uFF0C\u518D\u8C03\u6574\u504F\u597D\u3002";
    const PREP_START_ELEMENT_ID = "full-preparation-start";
    const PREP_CANCEL_ELEMENT_ID = "full-preparation-cancel";
    const PREP_MESSAGE_ELEMENT_ID = "full-preparation-message";
    function setStatus(supported) {
      const element = document.getElementById(STATUS_ELEMENT_ID);
      if (element === null) {
        console.log("[Course Copilot] side panel \u7F3A\u5C11 #page-status \u5143\u7D20");
        return;
      }
      element.textContent = supported ? SUPPORTED_TEXT : UNSUPPORTED_TEXT;
      element.classList.toggle("panel-status-supported", supported);
      const countElement = document.getElementById(COUNT_ELEMENT_ID);
      if (countElement !== null) countElement.hidden = !supported;
    }
    function setPanelCount(count) {
      const element = document.getElementById(COUNT_ELEMENT_ID);
      if (element === null) {
        console.log("[Course Copilot] side panel \u7F3A\u5C11 #panel-count \u5143\u7D20");
        return;
      }
      if (count === null || typeof count !== "number" || !Number.isFinite(count)) {
        element.textContent = "\u68C0\u6D4B\u5230\u8BFE\u7A0B\u9762\u677F\uFF1A\u2026";
        return;
      }
      element.textContent = `\u68C0\u6D4B\u5230\u8BFE\u7A0B\u9762\u677F\uFF1A${count}`;
    }
    const versionElement = document.getElementById(VERSION_ELEMENT_ID);
    if (versionElement === null) {
      console.log("[Course Copilot] side panel \u7F3A\u5C11 #fact-version \u5143\u7D20");
    } else {
      const manifest = chrome.runtime.getManifest();
      versionElement.textContent = manifest.version;
    }
    chrome.runtime.onMessage.addListener((message, sender) => {
      if (message?.type === PAGE_STATUS_MESSAGE) setStatus(message.supported === true);
      if (message?.type === PANEL_COUNT_MESSAGE) setPanelCount(typeof message.count === "number" ? message.count : null);
      if (message?.type === PREPARATION_EVENT_MESSAGE) {
        preparation.onEvent(preparationReportTabIdOf(message, sender?.tab?.id), message);
      }
      return false;
    });
    function renderPreparation(view) {
      const start = document.getElementById(PREP_START_ELEMENT_ID);
      const cancel = document.getElementById(PREP_CANCEL_ELEMENT_ID);
      const message = document.getElementById(PREP_MESSAGE_ELEMENT_ID);
      if (start === null || cancel === null || message === null) {
        console.log("[Course Copilot] side panel \u7F3A\u5C11\u6570\u636E\u51C6\u5907\u5143\u7D20");
        return;
      }
      start.hidden = !view.canStart;
      cancel.hidden = !view.canCancel;
      const lines = [];
      const progress = preparationProgressText(view.phase, view.clicks, view.hydration);
      if (progress !== null) lines.push(progress);
      else if (view.message !== null) lines.push(view.message);
      if (view.phase === "finished") {
        const finalLine = finalPageText(view.finalRowCount === null ? void 0 : { rowCount: view.finalRowCount });
        if (finalLine !== null) lines.push(finalLine);
      }
      message.textContent = lines.join(" ");
      message.hidden = lines.length === 0;
      deferredHandoff()?.consider(view.phase, view.stopReason, deferredPreparation()?.operationTabId() ?? null);
    }
    let preparationRef = null;
    function deferredPreparation() {
      return preparationRef;
    }
    let handoffRef = null;
    function deferredHandoff() {
      return handoffRef;
    }
    const preparation = createFullPreparationController({ onView: renderPreparation });
    preparationRef = preparation;
    const RECOMMENDATION_MESSAGE_ELEMENT_ID = "recommendation-message";
    const RECOMMENDATION_TEACHER_NOTICE_ELEMENT_ID = "recommendation-teacher-notice";
    const RECOMMENDATION_REVIEW_NOTICE_ELEMENT_ID = "recommendation-review-notice";
    const RECOMMENDATION_COUNTS_ELEMENT_ID = "recommendation-counts";
    const RECOMMENDATION_EMPTY_ELEMENT_ID = "recommendation-empty";
    const RECOMMENDATION_SECTION_ELEMENT_ID = "recommendation";
    function setLine(elementId, text) {
      const element = document.getElementById(elementId);
      if (element === null) return;
      const hasText = text !== null && text.length > 0;
      element.textContent = hasText ? text : "";
      element.hidden = !hasText;
    }
    function cardTargets() {
      const recommended = document.getElementById("card-list-recommended");
      const rated = document.getElementById("card-list-rated");
      const insufficient = document.getElementById("card-list-insufficient");
      const recommendedSection = document.getElementById("cards-recommended");
      const ratedSection = document.getElementById("cards-rated");
      const insufficientSection = document.getElementById("cards-insufficient");
      const disclaimer = document.getElementById("grade-disclaimer");
      const ratedToggle = document.getElementById("rated-toggle");
      const ratedCount = document.getElementById("rated-count");
      const ratedCards = document.getElementById("rated-cards");
      if (recommended === null || rated === null || insufficient === null || recommendedSection === null || ratedSection === null || insufficientSection === null || disclaimer === null || ratedToggle === null || ratedCount === null || ratedCards === null) {
        console.log("[Course Copilot] side panel \u7F3A\u5C11\u8BFE\u7A0B\u5361\u7247\u5143\u7D20");
        return null;
      }
      return {
        recommended,
        rated,
        insufficient,
        sections: { recommended: recommendedSection, rated: ratedSection, insufficient: insufficientSection },
        disclaimer,
        disclosure: { toggle: ratedToggle, count: ratedCount, panel: ratedCards }
      };
    }
    function wireRatedDisclosure() {
      const targets = cardTargets();
      if (targets === null || targets.disclosure === void 0) return;
      const { disclosure } = targets;
      disclosure.toggle.addEventListener("click", () => {
        const expanded = disclosure.toggle.getAttribute("aria-expanded") === "true";
        setRatedCollapsed({ toggle: disclosure.toggle, panel: disclosure.panel }, expanded);
      });
    }
    wireRatedDisclosure();
    function renderRecommendation(view, result) {
      const section = document.getElementById(RECOMMENDATION_SECTION_ELEMENT_ID);
      if (section === null) {
        console.log("[Course Copilot] side panel \u7F3A\u5C11\u63A8\u8350\u7ED3\u679C\u5143\u7D20");
        return;
      }
      const hasAnything = view.status !== "idle" || view.pageNotice !== null || view.reviewNotice !== null || view.teacherNotice !== null || view.counts !== null || view.emptyNotice !== null;
      section.hidden = !hasAnything;
      setLine(RECOMMENDATION_MESSAGE_ELEMENT_ID, view.pageNotice ?? (view.message.length > 0 ? view.message : null));
      setLine(RECOMMENDATION_TEACHER_NOTICE_ELEMENT_ID, view.teacherNotice);
      setLine(RECOMMENDATION_REVIEW_NOTICE_ELEMENT_ID, view.reviewNotice);
      setLine(RECOMMENDATION_EMPTY_ELEMENT_ID, view.emptyNotice);
      const counts = document.getElementById(RECOMMENDATION_COUNTS_ELEMENT_ID);
      if (counts !== null) {
        counts.hidden = view.counts === null;
        if (view.counts !== null) {
          setCount("recommendation-count-recommended", RECOMMENDATION_LABELS.recommended, view.counts.recommended);
          setCount("recommendation-count-rated", RECOMMENDATION_LABELS.rated, view.counts.rated);
          setCount("recommendation-count-insufficient", RECOMMENDATION_LABELS.insufficient, view.counts.insufficient);
        }
      }
      const targets = cardTargets();
      if (targets !== null) {
        renderCourseCards(targets, view.counts === null ? null : result);
      }
    }
    function setCount(elementId, label, value) {
      const element = document.getElementById(elementId);
      if (element === null) return;
      element.textContent = String(value);
      element.setAttribute("data-label", label);
    }
    let currentRecommendationResult = null;
    const recommendation = createRecommendationRequestController({
      sink: (state) => {
        currentRecommendationResult = state.status === "success" ? state.result : null;
        renderRecommendation(recommendationResultView(state, preparation.view().stopReason), currentRecommendationResult);
      }
    });
    const handoff = createRecommendationHandoff({ request: (expectedTabId) => recommendation.request(expectedTabId) });
    handoffRef = handoff;
    function readPreferenceValues() {
      const values = {};
      for (const { key } of PREFERENCE_CONTROLS) {
        const slider = document.getElementById(`preference-${key}`);
        values[key] = slider === null ? Number.NaN : Number(slider.value);
      }
      return values;
    }
    function refreshPreferenceReadouts() {
      const values = readPreferenceValues();
      const percentages = preferencePercentagesOf(values);
      PREFERENCE_CONTROLS.forEach(({ key }, index) => {
        const value = values[key];
        const valueElement = document.getElementById(`preference-value-${key}`);
        if (valueElement !== null) valueElement.textContent = `${String(value)}/${PREFERENCE_MAX}`;
        const percentElement = document.getElementById(`preference-percent-${key}`);
        if (percentElement !== null) percentElement.textContent = `${percentages[index]}%`;
      });
      const problem = preferenceProblemOf(values);
      const problemElement = document.getElementById(PREFERENCES_PROBLEM_ELEMENT_ID);
      if (problemElement !== null) {
        problemElement.textContent = problem === null ? "" : PREFERENCE_PROBLEM_TEXT[problem.code];
        problemElement.hidden = problem === null;
      }
      const apply = document.getElementById(PREFERENCES_APPLY_ELEMENT_ID);
      if (apply !== null) apply.disabled = problem !== null;
    }
    function wirePreferenceEditor() {
      for (const { key } of PREFERENCE_CONTROLS) {
        const slider = document.getElementById(`preference-${key}`);
        if (slider !== null) slider.addEventListener("input", refreshPreferenceReadouts);
      }
      const reset = document.getElementById(PREFERENCES_RESET_ELEMENT_ID);
      if (reset !== null) {
        reset.addEventListener("click", () => {
          const defaults = defaultPreferenceValues();
          for (const { key } of PREFERENCE_CONTROLS) {
            const slider = document.getElementById(`preference-${key}`);
            if (slider !== null) slider.value = String(defaults[key]);
          }
          refreshPreferenceReadouts();
        });
      }
      const apply = document.getElementById(PREFERENCES_APPLY_ELEMENT_ID);
      if (apply !== null) {
        apply.addEventListener("click", () => {
          const values = readPreferenceValues();
          if (preferenceProblemOf(values) !== null) {
            refreshPreferenceReadouts();
            return;
          }
          const targetTabId = recommendation.tabId();
          if (targetTabId === null) {
            const problemElement = document.getElementById(PREFERENCES_PROBLEM_ELEMENT_ID);
            if (problemElement !== null) {
              problemElement.textContent = PREFERENCES_NO_TARGET_TEXT;
              problemElement.hidden = false;
            }
            return;
          }
          void recommendation.request(targetTabId, preferencePayloadOf(values));
        });
      }
      refreshPreferenceReadouts();
    }
    wirePreferenceEditor();
    renderRecommendation(recommendationIdleView(preparation.view().stopReason, preparation.view().phase === "finished"), null);
    document.getElementById(PREP_START_ELEMENT_ID)?.addEventListener("click", () => {
      handoff.reset();
      void preparation.start();
    });
    document.getElementById(PREP_CANCEL_ELEMENT_ID)?.addEventListener("click", () => {
      void preparation.cancel();
    });
    async function refreshFromActiveTab() {
      let tabId = null;
      try {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        const first = tabs[0];
        if (first !== void 0 && typeof first.id === "number") tabId = first.id;
      } catch {
        tabId = null;
      }
      if (tabId === null) {
        setStatus(false);
        setPanelCount(null);
        return;
      }
      try {
        const response = await chrome.runtime.sendMessage({ type: PING_MESSAGE, tabId });
        const record = typeof response === "object" && response !== null ? response : {};
        setStatus(record.supported === true);
        setPanelCount(typeof record.panelCount === "number" ? record.panelCount : null);
      } catch {
        setStatus(false);
        setPanelCount(null);
      }
    }
    void refreshFromActiveTab();
    void preparation.restore();
    console.log("[Course Copilot] side panel \u5DF2\u52A0\u8F7D");
  })();
})();
